/*
 * Meu IPTV — servidor intermediário
 * - Entrega o app (pasta public/)
 * - Repassa as chamadas ao servidor IPTV (o Safari bloqueia a chamada direta)
 * - Opcionalmente repassa imagens e vídeo (necessário apenas se o site usar https)
 * Sem dependências: basta Node.js 16+.
 */
'use strict';
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const CONFIG_FILE = path.join(ROOT, 'config.json');
const PORT = parseInt(process.env.PORT || '80', 10);

/* ---------- Código de acesso (impede que estranhos usem o seu servidor) ---------- */
function loadConfig() {
  let cfg = {};
  try { cfg = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')); } catch (e) {}
  if (process.env.ACCESS_KEY) cfg.accessKey = process.env.ACCESS_KEY;
  if (!cfg.accessKey) {
    cfg.accessKey = crypto.randomBytes(6).toString('hex');
    try { fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2)); } catch (e) {}
  }
  return cfg;
}
const CFG = loadConfig();
function keyOk(k) {
  if (typeof k !== 'string') return false;
  const a = Buffer.from(k), b = Buffer.from(CFG.accessKey);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

/* ---------- Proteção: não repassar para a rede interna do servidor ---------- */
function blockedHost(h) {
  if (process.env.ALLOW_LOCAL === '1') return false; // apenas para testes
  h = h.toLowerCase().replace(/^\[|\]$/g, '');
  return h === 'localhost' || h === '0.0.0.0' || h === '::1' || h.endsWith('.localhost') ||
    /^127\./.test(h) || /^169\.254\./.test(h) || h === 'metadata.google.internal';
}

const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1';

/* Faz a requisição seguindo redirecionamentos */
function upstream(target, req, res0, cb, hops) {
  hops = hops || 0;
  let u;
  try { u = new URL(target); } catch (e) { return cb(new Error('URL inválida')); }
  if (!/^https?:$/.test(u.protocol) || blockedHost(u.hostname)) return cb(new Error('Destino não permitido'));
  const lib = u.protocol === 'https:' ? https : http;
  const headers = { 'User-Agent': UA, 'Accept': '*/*' };
  if (req.headers.range) headers.Range = req.headers.range;
  const r = lib.request(u, { method: 'GET', headers, timeout: 25000 }, (res) => {
    if ([301, 302, 303, 307, 308].indexOf(res.statusCode) > -1 && res.headers.location && hops < 6) {
      res.resume();
      return upstream(new URL(res.headers.location, u).toString(), req, res0, cb, hops + 1);
    }
    cb(null, res, u.toString(), r);
  });
  r.on('timeout', () => r.destroy(new Error('Tempo esgotado')));
  r.on('error', (e) => cb(e));
  r.end();
  res0.on('close', () => { if (!res0.writableEnded) r.destroy(); });
}

/* Reescreve uma lista HLS (.m3u8) para que os pedaços também passem por aqui */
function rewriteM3u8(text, baseUrl, key) {
  const wrap = (s) => '/p?k=' + encodeURIComponent(key) + '&u=' + encodeURIComponent(new URL(s, baseUrl).toString());
  return text.split(/\r?\n/).map((line) => {
    const t = line.trim();
    if (!t) return line;
    if (t[0] === '#') return line.replace(/URI="([^"]+)"/g, (m, uri) => 'URI="' + wrap(uri) + '"');
    return wrap(t);
  }).join('\n');
}

function proxy(req, res, q) {
  if (!keyOk(q.get('k'))) { res.writeHead(403); return res.end('Código de acesso inválido'); }
  const target = q.get('u');
  if (!target) { res.writeHead(400); return res.end('Falta o endereço'); }
  upstream(target, req, res, (err, up, finalUrl) => {
    if (err) {
      if (!res.headersSent) { res.writeHead(502, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end(err.message); }
      return;
    }
    const ct = String(up.headers['content-type'] || '');
    const isM3u8 = /mpegurl/i.test(ct) || /\.m3u8(\?|$)/i.test(finalUrl);
    if (isM3u8 && up.statusCode < 300) {
      const chunks = [];
      up.on('data', (c) => chunks.push(c));
      up.on('end', () => {
        const body = rewriteM3u8(Buffer.concat(chunks).toString('utf8'), finalUrl, q.get('k'));
        res.writeHead(200, { 'Content-Type': 'application/vnd.apple.mpegurl', 'Cache-Control': 'no-cache' });
        res.end(body);
      });
      return;
    }
    const out = {};
    ['content-type', 'content-length', 'content-range', 'accept-ranges', 'last-modified', 'etag'].forEach((h) => {
      if (up.headers[h]) out[h] = up.headers[h];
    });
    if (/^image\//.test(ct)) out['cache-control'] = 'public, max-age=86400';
    res.writeHead(up.statusCode, out);
    up.pipe(res);
    res.on('close', () => up.destroy());
  });
}

/* ---------- Arquivos do app ---------- */
const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.png': 'image/png',
  '.svg': 'image/svg+xml', '.m3u': 'audio/x-mpegurl; charset=utf-8', '.webmanifest': 'application/manifest+json', '.ico': 'image/x-icon'
};
function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/' || rel === '') rel = '/index.html';
  const file = path.normalize(path.join(PUBLIC, rel));
  if (file.indexOf(PUBLIC) !== 0) { res.writeHead(403); return res.end(); }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404); return res.end('Não encontrado'); }
    const ext = path.extname(file);
    res.writeHead(200, {
      'Content-Type': TYPES[ext] || 'application/octet-stream',
      'Content-Length': st.size,
      // sem cache para o app: cada atualização aparece na hora
      'Cache-Control': ext === '.png' ? 'public, max-age=604800' : 'no-cache'
    });
    fs.createReadStream(file).pipe(res);
  });
}

/* ---------- Lista de canais gratuitos: testa cada canal e guarda só os que funcionam ---------- */
const DATA = path.join(ROOT, 'data');
const LIST_SRC = path.join(PUBLIC, 'listas', 'brasil.m3u');
const LIST_OK = path.join(DATA, 'brasil-ok.m3u');
const LIST_STATUS = path.join(DATA, 'brasil-status.json');
let checking = false;

function fetchText(target, maxBytes, timeoutMs, hops) {
  hops = hops || 0;
  return new Promise((resolve) => {
    let u;
    try { u = new URL(target); } catch (e) { return resolve(null); }
    if (!/^https?:$/.test(u.protocol) || blockedHost(u.hostname)) return resolve(null);
    const lib = u.protocol === 'https:' ? https : http;
    let done = false;
    const finish = (v) => { if (!done) { done = true; clearTimeout(t); resolve(v); } };
    const r = lib.request(u, { method: 'GET', headers: { 'User-Agent': UA, 'Accept': '*/*' } }, (res) => {
      if ([301, 302, 303, 307, 308].indexOf(res.statusCode) > -1 && res.headers.location && hops < 5) {
        res.resume();
        fetchText(new URL(res.headers.location, u).toString(), maxBytes, timeoutMs, hops + 1).then(finish);
        return;
      }
      if (res.statusCode !== 200) { res.resume(); return finish(null); }
      const chunks = []; let size = 0;
      res.on('data', (c) => {
        chunks.push(c); size += c.length;
        if (size >= maxBytes) { r.destroy(); finish({ url: u.toString(), body: Buffer.concat(chunks).toString('utf8') }); }
      });
      res.on('end', () => finish({ url: u.toString(), body: Buffer.concat(chunks).toString('utf8') }));
      res.on('error', () => finish(null));
    });
    const t = setTimeout(() => { r.destroy(); finish(null); }, timeoutMs);
    r.on('error', () => finish(null));
    r.end();
  });
}

async function streamWorks(url) {
  const a = await fetchText(url, 65536, 9000);
  if (!a || a.body.indexOf('#EXTM3U') < 0) return false;
  if (a.body.indexOf('#EXT-X-STREAM-INF') < 0) return /#EXTINF|#EXT-X-TARGETDURATION/.test(a.body);
  // lista "mestre": confere se a primeira qualidade também responde
  const line = a.body.split(/\r?\n/).find((l, i, arr) => l && l[0] !== '#' && i > 0 && /#EXT-X-STREAM-INF/.test(arr[i - 1]));
  if (!line) return true;
  const b = await fetchText(new URL(line.trim(), a.url).toString(), 65536, 9000);
  return !!(b && b.body.indexOf('#EXTM3U') > -1);
}

function parseList(text) {
  const out = []; let cur = null;
  text.split(/\r?\n/).forEach((raw) => {
    const l = raw.trim();
    if (l.startsWith('#EXTINF')) cur = { info: l, alts: [] };
    else if (l.startsWith('#EXTVLCOPT:alt=') && cur) cur.alts.push(l.slice(15));
    else if (l && l[0] !== '#' && cur) { cur.url = l; out.push(cur); cur = null; }
  });
  return out;
}

async function checkList() {
  if (checking) return;
  checking = true;
  try {
    const items = parseList(fs.readFileSync(LIST_SRC, 'utf8'));
    const ok = new Array(items.length).fill(null);
    let next = 0;
    async function worker() {
      while (next < items.length) {
        const i = next++, it = items[i];
        for (const url of [it.url].concat(it.alts)) {
          if (await streamWorks(url)) { ok[i] = { info: it.info, url }; break; }
        }
      }
    }
    await Promise.all(Array.from({ length: 12 }, worker));
    const good = ok.filter(Boolean);
    fs.mkdirSync(DATA, { recursive: true });
    fs.writeFileSync(LIST_OK + '.tmp', '#EXTM3U\n' + good.map((g) => g.info + '\n' + g.url).join('\n') + '\n');
    fs.renameSync(LIST_OK + '.tmp', LIST_OK);
    fs.writeFileSync(LIST_STATUS, JSON.stringify({ checkedAt: new Date().toISOString(), total: items.length, working: good.length }));
    console.log('Lista verificada: ' + good.length + ' de ' + items.length + ' canais funcionando');
  } catch (e) {
    console.log('Falha ao verificar a lista: ' + e.message);
  } finally { checking = false; }
}
setTimeout(checkList, 20000);
setInterval(checkList, 6 * 3600 * 1000);

function serveList(res, file, type) {
  fs.readFile(file, (err, buf) => {
    if (err && file === LIST_OK) return serveList(res, LIST_SRC, type); // ainda não verificada
    if (err) { res.writeHead(404); return res.end(); }
    res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-cache' });
    res.end(buf);
  });
}

const server = http.createServer((req, res) => {
  let u;
  try { u = new URL(req.url, 'http://local'); } catch (e) { res.writeHead(400); return res.end(); }
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
  if (u.pathname === '/p') return proxy(req, res, u.searchParams);
  if (u.pathname === '/check') {
    const ok = keyOk(u.searchParams.get('k'));
    res.writeHead(ok ? 200 : 403, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    return res.end(JSON.stringify({ ok }));
  }
  if (u.pathname === '/listas/brasil-ok.m3u') return serveList(res, LIST_OK, 'audio/x-mpegurl; charset=utf-8');
  if (u.pathname === '/listas/status.json') return serveList(res, LIST_STATUS, 'application/json');
  serveStatic(req, res, u.pathname);
});
server.listen(PORT, () => {
  console.log('Meu IPTV rodando na porta ' + PORT);
  console.log('Código de acesso: ' + CFG.accessKey);
});
