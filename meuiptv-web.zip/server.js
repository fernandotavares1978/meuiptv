/*
 * Meu IPTV — servidor intermediário
 * - Entrega o app (pasta public/)
 * - Repassa as chamadas ao servidor IPTV (o Safari bloqueia a chamada direta)
 * - Opcionalmente repassa imagens e vídeo (necessário apenas se o site usar https)
 * Sem dependências: basta Node.js 16+.
 */
'use strict';
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const CONFIG_FILE = path.join(ROOT, 'config.json');
const PORT = parseInt(process.env.PORT || '80', 10);

/* ---------- Código de acesso (impede que estranhos usem o seu servidor) ---------- */
function loadConfig() {
  let cfg = {};
  try { cfg = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')); } catch (e) {}
  if (process.env.ACCESS_KEY) cfg.accessKey = process.env.ACCESS_KEY;
  if (!cfg.accessKey) {
    cfg.accessKey = crypto.randomBytes(6).toString('hex');
    try { fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2)); } catch (e) {}
  }
  return cfg;
}
const CFG = loadConfig();
function keyOk(k) {
  if (typeof k !== 'string') return false;
  const a = Buffer.from(k), b = Buffer.from(CFG.accessKey);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

/* ---------- Proteção: não repassar para a rede interna do servidor ---------- */
function blockedHost(h) {
  if (process.env.ALLOW_LOCAL === '1') return false; // apenas para testes
  h = h.toLowerCase().replace(/^\[|\]$/g, '');
  return h === 'localhost' || h === '0.0.0.0' || h === '::1' || h.endsWith('.localhost') ||
    /^127\./.test(h) || /^169\.254\./.test(h) || h === 'metadata.google.internal';
}

const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1';

/* Faz a requisição seguindo redirecionamentos */
function upstream(target, req, res0, cb, hops) {
  hops = hops || 0;
  let u;
  try { u = new URL(target); } catch (e) { return cb(new Error('URL inválida')); }
  if (!/^https?:$/.test(u.protocol) || blockedHost(u.hostname)) return cb(new Error('Destino não permitido'));
  const lib = u.protocol === 'https:' ? https : http;
  const headers = { 'User-Agent': UA, 'Accept': '*/*' };
  if (req.headers.range) headers.Range = req.headers.range;
  const r = lib.request(u, { method: 'GET', headers, timeout: 25000 }, (res) => {
    if ([301, 302, 303, 307, 308].indexOf(res.statusCode) > -1 && res.headers.location && hops < 6) {
      res.resume();
      return upstream(new URL(res.headers.location, u).toString(), req, res0, cb, hops + 1);
    }
    cb(null, res, u.toString(), r);
  });
  r.on('timeout', () => r.destroy(new Error('Tempo esgotado')));
  r.on('error', (e) => cb(e));
  r.end();
  res0.on('close', () => { if (!res0.writableEnded) r.destroy(); });
}

/* Reescreve uma lista HLS (.m3u8) para que os pedaços também passem por aqui */
function sign(u) { return crypto.createHmac('sha256', CFG.accessKey).update(u).digest('hex').slice(0, 16); }
function rewriteM3u8(text, baseUrl, key) {
  const wrap = (s) => {
    const abs = new URL(s, baseUrl).toString();
    return keyOk(key) ? '/p?k=' + encodeURIComponent(key) + '&u=' + encodeURIComponent(abs) : '/p?s=' + sign(abs) + '&u=' + encodeURIComponent(abs);
  };
  return text.split(/\r?\n/).map((line) => {
    const t = line.trim();
    if (!t) return line;
    if (t[0] === '#') return line.replace(/URI="([^"]+)"/g, (m, uri) => 'URI="' + wrap(uri) + '"');
    return wrap(t);
  }).join('\n');
}

function proxy(req, res, q) {
  const target = q.get('u');
  if (!target) { res.writeHead(400); return res.end('Falta o endereço'); }
  // Liberado com o código de acesso, com assinatura (pedaços de um stream já autorizado)
  // ou quando o endereço pertence a um canal cadastrado (player com hls.js sem código)
  const allowed = keyOk(q.get('k')) || (q.get('s') && q.get('s') === sign(target)) || channelHostAllowed(target);
  if (!allowed) { res.writeHead(403); return res.end('Código de acesso inválido'); }
  upstream(target, req, res, (err, up, finalUrl) => {
    if (err) {
      if (!res.headersSent) { res.writeHead(502, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end(err.message); }
      return;
    }
    const ct = String(up.headers['content-type'] || '');
    const isM3u8 = /mpegurl/i.test(ct) || /\.m3u8(\?|$)/i.test(finalUrl);
    if (isM3u8 && up.statusCode < 300) {
      const chunks = [];
      up.on('data', (c) => chunks.push(c));
      up.on('end', () => {
        const body = rewriteM3u8(Buffer.concat(chunks).toString('utf8'), finalUrl, q.get('k'));
        res.writeHead(200, { 'Content-Type': 'application/vnd.apple.mpegurl', 'Cache-Control': 'no-cache' });
        res.end(body);
      });
      return;
    }
    const out = {};
    ['content-type', 'content-length', 'content-range', 'accept-ranges', 'last-modified', 'etag'].forEach((h) => {
      if (up.headers[h]) out[h] = up.headers[h];
    });
    if (/^image\//.test(ct)) out['cache-control'] = 'public, max-age=86400';
    res.writeHead(up.statusCode, out);
    up.pipe(res);
    res.on('close', () => up.destroy());
  });
}


/* ======================================================================
 * GERENCIADOR DE FONTES M3U
 * Fontes (lista embutida, URL, arquivo, cadastro manual) -> canais
 * Cada canal é verificado periodicamente: ok, fora do ar, incompatível ou DRM
 * ====================================================================== */
const DATA = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA, 'db.json');
const SRC_DIR = path.join(DATA, 'sources');
const BUILTIN_LIST = path.join(PUBLIC, 'listas', 'brasil.m3u');
fs.mkdirSync(SRC_DIR, { recursive: true });

const STATUS_PT = { ok: 'Funcionando', down: 'Fora do ar', incompatible: 'Incompatível', drm: 'Protegido (DRM)', unknown: 'Não verificado' };
const CATEGORIES = ['Canais abertos', 'Notícias', 'Esportes', 'Entretenimento', 'Filmes e Séries', 'Infantil',
  'Documentários', 'Música', 'Educativos', 'Religiosos', 'Governo e Legislativo', 'Outros'];

let db = loadDb();
function loadDb() {
  try {
    const d = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    d.sources = d.sources || []; d.channels = d.channels || {}; d.settings = d.settings || {};
    return d;
  } catch (e) {
    return { version: 1, sources: [], channels: {}, settings: {}, lastFullCheck: 0 };
  }
}
db.settings = Object.assign({ showUnchecked: true, checkHours: 6 }, db.settings);
let saveTimer = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      fs.writeFileSync(DB_FILE + '.tmp', JSON.stringify(db));
      fs.renameSync(DB_FILE + '.tmp', DB_FILE);
    } catch (e) { console.log('Erro ao salvar: ' + e.message); }
  }, 400);
}
function hash(s) { return crypto.createHash('sha1').update(s).digest('hex').slice(0, 12); }
function newId() { return crypto.randomBytes(5).toString('hex'); }
function norm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim(); }

/* ---------- Categorias padronizadas ---------- */
const CAT_RULES = [
  ['Esportes', /esport|sport|futebol|futbol|fight|luta|ufc|\bge fast\b|caze|soccer|nba|nfl|f[oó]rmula|racing/],
  ['Notícias', /not[ií]cia|news|jornal|\bcnn\b|telejornal|weather|clima/],
  ['Infantil', /infantil|kids|crian|desenho|cartoon|anima|junior|teen|toon/],
  ['Filmes e Séries', /filme|movie|cine|s[eé]rie|series|novela|sitcom|drama|terror|a[cç][aã]o/],
  ['Documentários', /document|hist[oó]ri|natureza|nature|ci[eê]ncia|science|discovery|animal|wild/],
  ['Música', /m[uú]sica|music|r[aá]dio|radio|rock|\bpop\b|clip|sertanej|funk|samba|karaoke/],
  ['Educativos', /educa|cultura|universit|\bunb\b|futura|escola|libras|sesc|saude/],
  ['Religiosos', /relig|gospel|cat[oó]lic|evang|igreja|padre|\bdeus\b|crist|aparecida|can[cç][aã]o nova|universal|adora/],
  ['Governo e Legislativo', /legislat|governo|c[aâ]mara|senado|assembl|justi[cç]a|\bgov\b|camara|tv justica/],
  ['Entretenimento', /entretenimento|entertainment|humor|com[eé]dia|comedy|reality|lifestyle|estilo|culin|chef|viagem|travel|pet|game|show|variedades/],
  ['Canais abertos', /abertos|aberta|general|geral|\btv\b|rede|sbt|record|band|globo/]
];
function categorize(group, name) {
  const g = norm(group), n = norm(name);
  for (const c of CATEGORIES) if (norm(c) === g) return c;
  if (g === 'abertos e variedades') return 'Canais abertos';
  for (const [cat, re] of CAT_RULES) if (cat !== 'Canais abertos' && re.test(g)) return cat;
  for (const [cat, re] of CAT_RULES) if (cat !== 'Canais abertos' && re.test(n)) return cat;
  if (/pluto|samsung|rakuten|fast/.test(g)) return 'Entretenimento';
  if (CAT_RULES[CAT_RULES.length - 1][1].test(g + ' ' + n)) return 'Canais abertos';
  return 'Outros';
}

/* ---------- Leitura de playlist M3U / M3U8 ---------- */
function parseM3u(text) {
  const out = []; let cur = null;
  String(text).replace(/^﻿/, '').split(/\r?\n/).forEach((raw) => {
    const l = raw.trim();
    if (!l) return;
    if (l.startsWith('#EXTINF')) {
      const attr = (k) => { const m = l.match(new RegExp(k + '="([^"]*)"', 'i')); return m ? m[1].trim() : ''; };
      const comma = l.lastIndexOf(',');
      cur = { name: comma > -1 ? l.slice(comma + 1).trim() : '', tvgId: attr('tvg-id'), logo: attr('tvg-logo'),
        group: attr('group-title'), alts: [] };
    } else if (l.startsWith('#EXTGRP:') && cur && !cur.group) cur.group = l.slice(8).trim();
    else if (l.startsWith('#EXTVLCOPT:alt=') && cur) cur.alts.push(l.slice(15).trim());
    else if (l[0] !== '#') {
      if (!cur) cur = { name: '', tvgId: '', logo: '', group: '', alts: [] };
      cur.url = l;
      if (!cur.name) cur.name = l.split('/').pop().split('?')[0] || 'Canal';
      out.push(cur);
      cur = null;
    }
  });
  return out;
}

/* ---------- Requisição HTTP com limite (para testes e downloads) ---------- */
function fetchUrl(target, opt, hops) {
  opt = opt || {}; hops = hops || 0;
  const maxBytes = opt.maxBytes || 65536, timeoutMs = opt.timeout || 10000;
  return new Promise((resolve) => {
    let u;
    try { u = new URL(target); } catch (e) { return resolve({ error: 'Endereço inválido' }); }
    if (!/^https?:$/.test(u.protocol)) return resolve({ error: 'Protocolo ' + u.protocol.replace(':', '').toUpperCase() + ' não é suportado por navegadores' });
    if (blockedHost(u.hostname)) return resolve({ error: 'Destino não permitido' });
    const lib = u.protocol === 'https:' ? https : http;
    let done = false;
    const finish = (v) => { if (!done) { done = true; clearTimeout(t); resolve(v); } };
    const r = lib.request(u, { method: 'GET', headers: { 'User-Agent': UA, 'Accept': '*/*' } }, (res) => {
      if ([301, 302, 303, 307, 308].indexOf(res.statusCode) > -1 && res.headers.location && hops < 6) {
        res.resume();
        fetchUrl(new URL(res.headers.location, u).toString(), opt, hops + 1).then(finish);
        return;
      }
      const chunks = []; let size = 0;
      const end = () => finish({ status: res.statusCode, ct: String(res.headers['content-type'] || '').toLowerCase(), url: u.toString(), buf: Buffer.concat(chunks) });
      res.on('data', (c) => { chunks.push(c); size += c.length; if (size >= maxBytes) { r.destroy(); end(); } });
      res.on('end', end);
      res.on('error', end);
    });
    const t = setTimeout(() => { r.destroy(); finish({ error: 'Sem resposta (tempo esgotado)' }); }, timeoutMs);
    r.on('error', (e) => finish({ error: e.code === 'ENOTFOUND' ? 'Endereço não encontrado (DNS)' : e.code === 'ECONNREFUSED' ? 'Conexão recusada' : 'Falha de conexão' }));
    r.end();
  });
}

/* ---------- Identificação de formato e disponibilidade ----------
 * Retorna { status, format, detail, url? }
 * status: ok | down | incompatible | drm      format: hls | mp4 | webm | audio | ts | dash | playlist | pagina | ? */
const DRM_RE = /METHOD=SAMPLE-AES|KEYFORMAT="(com\.apple\.streamingkeydelivery|urn:uuid:edef8ba9|com\.widevine|com\.microsoft\.playready)/i;
async function detect(url, depth) {
  depth = depth || 0;
  const scheme = (String(url).match(/^([a-z0-9+.-]+):/i) || [])[1];
  if (scheme && !/^https?$/i.test(scheme)) {
    return { status: 'incompatible', format: scheme.toLowerCase(), detail: 'Protocolo ' + scheme.toUpperCase() + ' não é reproduzido em navegadores' };
  }
  const r = await fetchUrl(url, { maxBytes: 131072, timeout: 10000 });
  if (r.error) return { status: 'down', format: '?', detail: r.error };
  if (r.status === 401 || r.status === 403) return { status: 'down', format: '?', detail: 'Acesso negado (' + r.status + ')' };
  if (r.status === 404 || r.status === 410) return { status: 'down', format: '?', detail: 'Não encontrado (' + r.status + ')' };
  if (r.status >= 400) return { status: 'down', format: '?', detail: 'Erro do servidor (' + r.status + ')' };
  const b = r.buf, txt = b.slice(0, 131072).toString('utf8'), head = txt.slice(0, 2048).trimStart();
  // HLS ou playlist M3U
  if (head.startsWith('#EXTM3U') || /mpegurl/.test(r.ct)) {
    const isHls = /#EXT-X-(STREAM-INF|TARGETDURATION|MEDIA-SEQUENCE|INDEPENDENT-SEGMENTS|VERSION|ENDLIST|PLAYLIST-TYPE)/.test(txt);
    if (!isHls) {
      const n = (txt.match(/#EXTINF/g) || []).length;
      if (n > 0) return { status: 'incompatible', format: 'playlist', detail: 'É uma playlist com ' + (n >= 50 ? 'muitos' : n) + ' itens — cadastre como fonte' };
      return { status: 'down', format: 'hls', detail: 'Lista HLS vazia' };
    }
    if (DRM_RE.test(txt)) return { status: 'drm', format: 'hls', detail: 'Protegido por DRM — use o app oficial do serviço' };
    if (/#EXT-X-STREAM-INF/.test(txt) && depth === 0) {
      const lines = txt.split(/\r?\n/);
      const idx = lines.findIndex((l) => /#EXT-X-STREAM-INF/.test(l));
      const variant = lines.slice(idx + 1).find((l) => l.trim() && l.trim()[0] !== '#');
      if (variant) {
        const v = await detect(new URL(variant.trim(), r.url).toString(), 1);
        if (v.status !== 'ok') return { status: v.status, format: 'hls', detail: 'Qualidade principal: ' + v.detail };
      }
      const res = (txt.match(/RESOLUTION=\d+x(\d+)/g) || []).map((x) => +x.split('x')[1]);
      return { status: 'ok', format: 'hls', detail: 'HLS' + (res.length ? ' até ' + Math.max.apply(null, res) + 'p' : '') };
    }
    if (!/#EXTINF/.test(txt)) return { status: 'down', format: 'hls', detail: 'Lista HLS sem segmentos' };
    return { status: 'ok', format: 'hls', detail: /#EXT-X-ENDLIST/.test(txt) ? 'HLS (sob demanda)' : 'HLS ao vivo' };
  }
  if (/<MPD[\s>]/i.test(head)) {
    if (/ContentProtection/i.test(txt)) return { status: 'drm', format: 'dash', detail: 'DASH com DRM — use o app oficial do serviço' };
    return { status: 'incompatible', format: 'dash', detail: 'Formato DASH (.mpd) não suportado neste player' };
  }
  if (/text\/html/.test(r.ct) || /^<!doctype html|^<html/i.test(head)) return { status: 'incompatible', format: 'pagina', detail: 'O endereço é uma página da web, não um stream' };
  if (b.length > 8 && b.slice(4, 8).toString('latin1') === 'ftyp' || /video\/mp4|video\/quicktime/.test(r.ct)) return { status: 'ok', format: 'mp4', detail: 'Vídeo MP4' };
  if (b.length > 4 && b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3 || /video\/webm|matroska/.test(r.ct)) {
    return { status: 'incompatible', format: 'webm', detail: 'WebM/MKV: não toca no iPhone/iPad' };
  }
  if (/audio\/(mpeg|aac|mp4|x-m4a|ogg)/.test(r.ct) || (b[0] === 0x49 && b[1] === 0x44 && b[2] === 0x33)) return { status: 'ok', format: 'audio', detail: 'Áudio' };
  if (/video\/mp2t/.test(r.ct) || (b.length > 377 && b[0] === 0x47 && b[188] === 0x47)) {
    // MPEG-TS contínuo: tenta a versão HLS (comum em servidores Xtream)
    if (depth === 0 && /\.ts(\?|$)/i.test(url)) {
      const alt = url.replace(/\.ts(\?|$)/i, '.m3u8$1');
      const a = await detect(alt, 1);
      if (a.status === 'ok') return { status: 'ok', format: 'hls', detail: 'Convertido de .ts para HLS', url: alt };
    }
    return { status: 'incompatible', format: 'ts', detail: 'MPEG-TS contínuo: navegadores só tocam HLS' };
  }
  return { status: 'incompatible', format: '?', detail: 'Formato não reconhecido (' + (r.ct || 'sem tipo') + ')' };
}

/* ---------- Fontes ---------- */
function getSource(id) { return db.sources.find((s) => s.id === id); }
function sourceChannels(id) { return Object.values(db.channels).filter((c) => c.sourceId === id); }

async function readSourceText(src) {
  if (src.kind === 'builtin') return fs.readFileSync(BUILTIN_LIST, 'utf8');
  if (src.kind === 'file') return fs.readFileSync(path.join(SRC_DIR, src.id + '.m3u'), 'utf8');
  if (src.kind === 'url') {
    const r = await fetchUrl(src.url, { maxBytes: 40 * 1024 * 1024, timeout: 90000 });
    if (r.error) throw new Error(r.error);
    if (r.status !== 200) throw new Error('O servidor da lista respondeu ' + r.status);
    const t = r.buf.toString('utf8');
    if (t.trimStart().indexOf('#EXTM3U') !== 0 && t.indexOf('#EXTINF') < 0) throw new Error('O endereço não devolveu uma playlist M3U');
    return t;
  }
  return null;
}

async function refreshSource(src) {
  if (src.kind === 'manual') return;
  src.refreshing = true;
  try {
    const items = parseM3u(await readSourceText(src));
    if (!items.length) throw new Error('A playlist não tem canais');
    const seen = new Set();
    const byKey = {};
    items.forEach((it, i) => {
      const key = it.tvgId ? 'id:' + it.tvgId.split('@')[0].toLowerCase() : 'n:' + norm(it.name) + '|' + norm(it.group);
      if (byKey[key]) { byKey[key].alts.push(it.url); return; }
      byKey[key] = Object.assign({}, it, { key, order: i, alts: it.alts.slice() });
    });
    Object.values(byKey).forEach((it) => {
      const id = hash(src.id + '|' + it.key);
      seen.add(id);
      const old = db.channels[id];
      const ch = old || { id, sourceId: src.id, status: 'unknown', reports: 0, edited: {}, hidden: false, removed: false };
      if (old && old.url !== it.url) { ch.status = 'unknown'; ch.detail = ''; }
      Object.assign(ch, { key: it.key, name: it.name, url: it.url, alts: it.alts.slice(0, 4), logo: it.logo, group: it.group,
        tvgId: it.tvgId, order: it.order, category: categorize(it.group, it.name) });
      db.channels[id] = ch;
    });
    // canais que saíram da playlist (mantém os removidos para não voltarem)
    sourceChannels(src.id).forEach((c) => { if (!seen.has(c.id) && !c.removed && !c.manual) delete db.channels[c.id]; });
    src.lastFetch = Date.now(); src.lastError = ''; src.count = seen.size;
    console.log('Fonte "' + src.name + '" atualizada: ' + seen.size + ' canais');
  } catch (e) {
    src.lastError = e.message; src.lastFetch = Date.now();
    console.log('Fonte "' + src.name + '" falhou: ' + e.message);
  } finally {
    src.refreshing = false;
    save();
  }
  enqueueCheck(sourceChannels(src.id).filter((c) => c.status === 'unknown' && !c.removed).map((c) => c.id));
}

function ensureBuiltin() {
  if (!db.sources.find((s) => s.kind === 'builtin')) {
    db.sources.unshift({ id: 'gratuitos', name: 'Canais gratuitos do Brasil', kind: 'builtin', autoUpdate: true, intervalHours: 12,
      enabled: true, createdAt: Date.now(), count: 0 });
  }
  if (!db.sources.find((s) => s.kind === 'manual')) {
    db.sources.push({ id: 'manual', name: 'Cadastrados manualmente', kind: 'manual', autoUpdate: false, enabled: true, createdAt: Date.now(), count: 0 });
  }
}

/* ---------- Verificação (fila com vários testes em paralelo) ---------- */
const queue = []; const queued = new Set(); let workers = 0;
const progress = { running: false, total: 0, done: 0, startedAt: 0, finishedAt: 0 };
function enqueueCheck(ids) {
  ids.forEach((id) => { if (!queued.has(id) && db.channels[id]) { queued.add(id); queue.push(id); progress.total++; } });
  if (queue.length && !progress.running) { progress.running = true; progress.startedAt = Date.now(); }
  while (workers < 10 && queue.length) runWorker();
}
async function runWorker() {
  workers++;
  while (queue.length) {
    const id = queue.shift();
    queued.delete(id);
    const ch = db.channels[id];
    if (ch) await checkChannel(ch);
    progress.done++;
  }
  workers--;
  if (workers === 0) {
    progress.running = false; progress.finishedAt = Date.now();
    progress.total = 0; progress.done = 0;
    save();
  }
}
async function checkChannel(ch) {
  const urls = [ch.edited && ch.edited.url || ch.url].concat(ch.alts || []);
  let res = null;
  for (const u of urls) {
    res = await detect(u);
    if (res.status === 'ok') { res.url = res.url || u; break; }
    if (res.status === 'drm') break;
  }
  ch.status = res.status; ch.format = res.format; ch.detail = res.detail; ch.lastCheck = Date.now();
  if (res.status === 'ok') { ch.playUrl = res.url; ch.lastOk = Date.now(); ch.reports = 0; }
  else ch.playUrl = '';
  save();
  return res;
}
function checkAll(filter) {
  const ids = Object.values(db.channels).filter((c) => !c.removed && (!filter || filter(c))).map((c) => c.id);
  db.lastFullCheck = Date.now();
  enqueueCheck(ids);
  return ids.length;
}

/* ---------- Agendador: atualiza fontes e reverifica canais ---------- */
function tick() {
  const now = Date.now();
  db.sources.forEach((s) => {
    if (s.enabled !== false && s.autoUpdate && s.kind !== 'manual' && !s.refreshing &&
        now - (s.lastFetch || 0) > (s.intervalHours || 12) * 3600e3) refreshSource(s);
  });
  if (!progress.running && now - (db.lastFullCheck || 0) > (db.settings.checkHours || 6) * 3600e3) checkAll();
}
ensureBuiltin(); save();
setTimeout(tick, 5000);
setInterval(tick, 60000);

/* Hosts dos canais cadastrados (o player pode usar o servidor como ponte para eles) */
let hostCache = null, hostCacheAt = 0;
function channelHostAllowed(target) {
  if (!hostCache || Date.now() - hostCacheAt > 60000) {
    hostCache = new Set();
    Object.values(db.channels).forEach((c) => {
      if (c.removed) return;
      [c.url, c.playUrl, (c.edited || {}).url].concat(c.alts || []).forEach((x) => { try { if (x) hostCache.add(new URL(x).host); } catch (e) {} });
    });
    hostCacheAt = Date.now();
  }
  try { return hostCache.has(new URL(target).host); } catch (e) { return false; }
}

/* hls.js servido pelo próprio servidor (baixado uma vez e guardado) */
const HLS_FILE = path.join(DATA, 'hls.min.js');
const HLS_CDN = ['https://cdn.jsdelivr.net/npm/hls.js@1.5.13/dist/hls.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/hls.js/1.5.13/hls.min.js'];
let hlsLoading = null;
function serveHls(res) {
  const send = () => fs.readFile(HLS_FILE, (err, buf) => {
    if (err) { res.writeHead(404); return res.end(); }
    res.writeHead(200, { 'Content-Type': 'application/javascript; charset=utf-8', 'Cache-Control': 'public, max-age=86400' });
    res.end(buf);
  });
  if (fs.existsSync(HLS_FILE)) return send();
  hlsLoading = hlsLoading || (async () => {
    for (const u of HLS_CDN) {
      const r = await fetchUrl(u, { maxBytes: 3 * 1024 * 1024, timeout: 20000 });
      if (r.status === 200 && r.buf.length > 100000 && r.buf.toString('utf8', 0, 4000).indexOf('Hls') > -1) { fs.writeFileSync(HLS_FILE, r.buf); return; }
    }
  })().finally(() => { hlsLoading = null; });
  hlsLoading.then(send);
}

/* ---------- Playlist para o app ---------- */
function visibleChannels() {
  const enabled = new Set(db.sources.filter((s) => s.enabled !== false).map((s) => s.id));
  return Object.values(db.channels).filter((c) => enabled.has(c.sourceId) && !c.removed && !c.hidden &&
    (c.status === 'ok' || (c.status === 'unknown' && db.settings.showUnchecked)));
}
function playlistM3u() {
  const order = (c) => CATEGORIES.indexOf((c.edited || {}).category || c.category);
  const rows = visibleChannels().sort((a, b) => (order(a) - order(b)) ||
    String((a.edited || {}).name || a.name).localeCompare(String((b.edited || {}).name || b.name), 'pt-BR'));
  const q = (s) => String(s || '').replace(/"/g, "'");
  return '#EXTM3U\n' + rows.map((c) => {
    const e = c.edited || {};
    return '#EXTINF:-1 meu-id="' + c.id + '" tvg-logo="' + q(e.logo || c.logo) + '" group-title="' + q(e.category || c.category) +
      '",' + String(e.name || c.name).replace(/[\r\n]/g, ' ') + '\n' + (e.url || c.playUrl || c.url);
  }).join('\n') + '\n';
}

/* ---------- API administrativa ---------- */
function json(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', (c) => { size += c.length; if (size > limit) { reject(new Error('Arquivo grande demais')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch (e) { reject(new Error('Dados inválidos')); }
    });
    req.on('error', reject);
  });
}
function publicChannel(c) {
  const s = getSource(c.sourceId);
  return { id: c.id, sourceId: c.sourceId, source: s ? s.name : '', name: c.name, url: c.url, playUrl: c.playUrl || '', logo: c.logo,
    group: c.group, category: c.category, edited: c.edited || {}, hidden: !!c.hidden, removed: !!c.removed, manual: !!c.manual,
    status: c.status, statusText: STATUS_PT[c.status] || c.status, format: c.format || '', detail: c.detail || '',
    lastCheck: c.lastCheck || 0, lastOk: c.lastOk || 0, reports: c.reports || 0, lastReport: c.lastReport || 0 };
}
function summary() {
  const all = Object.values(db.channels).filter((c) => !c.removed);
  const by = { ok: 0, down: 0, incompatible: 0, drm: 0, unknown: 0 };
  all.forEach((c) => { by[c.status] = (by[c.status] || 0) + 1; });
  return {
    total: all.length, byStatus: by, visible: visibleChannels().length, removed: Object.values(db.channels).length - all.length,
    problems: all.filter((c) => c.reports > 0).length, categories: CATEGORIES, progress, settings: db.settings,
    lastFullCheck: db.lastFullCheck || 0,
    sources: db.sources.map((s) => Object.assign({}, s, { total: sourceChannels(s.id).filter((c) => !c.removed).length,
      ok: sourceChannels(s.id).filter((c) => c.status === 'ok' && !c.removed).length }))
  };
}

async function adminApi(req, res, u) {
  const k = req.headers['x-key'] || u.searchParams.get('k');
  if (!keyOk(k)) return json(res, 403, { error: 'Código de acesso inválido' });
  const parts = u.pathname.replace(/^\/api\/admin\/?/, '').split('/').filter(Boolean);
  const m = req.method;
  let body = {};
  if (m === 'POST' || m === 'PUT') {
    try { body = await readBody(req, 45 * 1024 * 1024); } catch (e) { return json(res, 400, { error: e.message }); }
  }
  const [a, id, action] = parts;

  if (a === 'summary' && m === 'GET') return json(res, 200, summary());

  if (a === 'settings' && m === 'PUT') {
    if (typeof body.showUnchecked === 'boolean') db.settings.showUnchecked = body.showUnchecked;
    if (body.checkHours) db.settings.checkHours = Math.max(1, Math.min(72, +body.checkHours));
    save();
    return json(res, 200, db.settings);
  }

  if (a === 'detect' && m === 'POST') {
    if (!body.url) return json(res, 400, { error: 'Informe o endereço' });
    const d = await detect(String(body.url).trim());
    return json(res, 200, Object.assign({ statusText: STATUS_PT[d.status] }, d));
  }

  if (a === 'sources') {
    if (!id && m === 'POST') {
      const kind = body.kind === 'file' ? 'file' : 'url';
      const src = { id: newId(), name: String(body.name || '').trim() || (kind === 'file' ? 'Arquivo ' + (body.fileName || '') : 'Lista ' + (db.sources.length)),
        kind, url: kind === 'url' ? String(body.url || '').trim() : '', fileName: body.fileName || '', autoUpdate: kind === 'url' ? body.autoUpdate !== false : false,
        intervalHours: Math.max(1, +body.intervalHours || 12), enabled: true, createdAt: Date.now(), count: 0 };
      if (kind === 'url' && !/^https?:\/\//i.test(src.url)) return json(res, 400, { error: 'O endereço precisa começar com http:// ou https://' });
      if (kind === 'file') {
        const content = String(body.content || '');
        if (content.indexOf('#EXTINF') < 0) return json(res, 400, { error: 'O arquivo não parece ser uma playlist M3U' });
        fs.writeFileSync(path.join(SRC_DIR, src.id + '.m3u'), content);
      }
      db.sources.push(src); save();
      await refreshSource(src);
      if (src.lastError && !src.count) {
        db.sources = db.sources.filter((s) => s.id !== src.id);
        try { fs.unlinkSync(path.join(SRC_DIR, src.id + '.m3u')); } catch (e) {}
        save();
        return json(res, 400, { error: src.lastError });
      }
      return json(res, 200, src);
    }
    const src = id && getSource(id);
    if (id && !src) return json(res, 404, { error: 'Fonte não encontrada' });
    if (src && action === 'refresh' && m === 'POST') { refreshSource(src); return json(res, 200, { ok: true }); }
    if (src && action === 'check' && m === 'POST') { return json(res, 200, { queued: checkAll((c) => c.sourceId === src.id) }); }
    if (src && m === 'PUT') {
      if (body.name) src.name = String(body.name).slice(0, 80);
      if (typeof body.autoUpdate === 'boolean') src.autoUpdate = body.autoUpdate;
      if (typeof body.enabled === 'boolean') src.enabled = body.enabled;
      if (body.intervalHours) src.intervalHours = Math.max(1, Math.min(168, +body.intervalHours));
      if (body.url && src.kind === 'url') src.url = String(body.url).trim();
      save();
      return json(res, 200, src);
    }
    if (src && m === 'DELETE') {
      if (src.kind === 'builtin' || src.kind === 'manual') return json(res, 400, { error: 'Esta fonte não pode ser apagada (pode ser desativada)' });
      sourceChannels(src.id).forEach((c) => delete db.channels[c.id]);
      db.sources = db.sources.filter((s) => s.id !== src.id);
      try { fs.unlinkSync(path.join(SRC_DIR, src.id + '.m3u')); } catch (e) {}
      save();
      return json(res, 200, { ok: true });
    }
    if (!id && m === 'GET') return json(res, 200, summary().sources);
  }

  if (a === 'channels') {
    if (!id && m === 'GET') {
      const q = norm(u.searchParams.get('q')), st = u.searchParams.get('status'), so = u.searchParams.get('source'),
        cat = u.searchParams.get('category'), off = +u.searchParams.get('offset') || 0, lim = Math.min(500, +u.searchParams.get('limit') || 100);
      let list = Object.values(db.channels).filter((c) => {
        if (st === 'removed') { if (!c.removed) return false; } else if (c.removed) return false;
        if (st === 'hidden') { if (!c.hidden) return false; } else if (st === 'problems') { if (!(c.reports > 0)) return false; }
        else if (st && st !== 'removed' && c.status !== st) return false;
        if (so && c.sourceId !== so) return false;
        if (cat && (c.edited.category || c.category) !== cat) return false;
        if (q && norm((c.edited.name || '') + ' ' + c.name + ' ' + c.url).indexOf(q) < 0) return false;
        return true;
      });
      list.sort((x, y) => String(x.edited.name || x.name).localeCompare(String(y.edited.name || y.name), 'pt-BR'));
      return json(res, 200, { total: list.length, items: list.slice(off, off + lim).map(publicChannel) });
    }
    if (!id && m === 'POST') {
      const url = String(body.url || '').trim();
      if (!url) return json(res, 400, { error: 'Informe o endereço do stream' });
      const d = await detect(url);
      if (d.format === 'playlist') return json(res, 409, { error: 'Esse endereço é uma playlist. Cadastre-o como fonte.', playlist: true });
      const chid = 'man' + hash(url);
      const ch = { id: chid, sourceId: 'manual', manual: true, key: chid, name: String(body.name || '').trim() || 'Canal ' + (Object.keys(db.channels).length + 1),
        url, alts: [], logo: String(body.logo || '').trim(), group: '', category: CATEGORIES.indexOf(body.category) > -1 ? body.category : 'Outros',
        edited: {}, hidden: false, removed: false, reports: 0, status: d.status, format: d.format, detail: d.detail,
        lastCheck: Date.now(), playUrl: d.status === 'ok' ? (d.url || url) : '', lastOk: d.status === 'ok' ? Date.now() : 0 };
      db.channels[chid] = ch;
      const man = getSource('manual'); if (man) man.count = sourceChannels('manual').length;
      save();
      return json(res, 200, publicChannel(ch));
    }
    if (id === 'remove-invalid' && m === 'POST') {
      const sts = Array.isArray(body.statuses) && body.statuses.length ? body.statuses : ['down', 'incompatible', 'drm'];
      let n = 0;
      Object.values(db.channels).forEach((c) => {
        if (!c.removed && sts.indexOf(c.status) > -1) {
          if (c.manual) delete db.channels[c.id]; else { c.removed = true; c.removedAt = Date.now(); }
          n++;
        }
      });
      save();
      return json(res, 200, { removed: n });
    }
    const ch = id && db.channels[id];
    if (!ch) return json(res, 404, { error: 'Canal não encontrado' });
    if (action === 'check' && m === 'POST') { await checkChannel(ch); return json(res, 200, publicChannel(ch)); }
    if (m === 'PUT') {
      const e = ch.edited = ch.edited || {};
      const urlBefore = e.url || ch.url;
      ['name', 'logo', 'url'].forEach((f) => {
        if (typeof body[f] === 'string') { const v = body[f].trim(); if (v && v !== ch[f]) e[f] = v; else delete e[f]; }
      });
      if (typeof body.category === 'string') { if (body.category && body.category !== ch.category) e.category = body.category; else delete e.category; }
      if (typeof body.hidden === 'boolean') ch.hidden = body.hidden;
      if (typeof body.removed === 'boolean') ch.removed = body.removed;
      if (body.resetReports) ch.reports = 0;
      if ((e.url || ch.url) !== urlBefore) { ch.status = 'unknown'; ch.playUrl = ''; enqueueCheck([ch.id]); }
      save();
      return json(res, 200, publicChannel(ch));
    }
    if (m === 'DELETE') {
      if (ch.manual) delete db.channels[ch.id]; else { ch.removed = true; ch.removedAt = Date.now(); }
      save();
      return json(res, 200, { ok: true });
    }
  }

  if (a === 'check' && m === 'POST') {
    const scope = body.scope || 'all';
    const n = checkAll(scope === 'unknown' ? (c) => c.status === 'unknown' : scope === 'failed' ? (c) => c.status !== 'ok' : null);
    return json(res, 200, { queued: n });
  }

  return json(res, 404, { error: 'Rota não encontrada' });
}

/* Relato de falha de reprodução vindo do player (público, só incrementa contador) */
const reportLimit = new Map();
async function reportApi(req, res) {
  let body = {};
  try { body = await readBody(req, 4096); } catch (e) { return json(res, 400, { error: 'inválido' }); }
  const ch = db.channels[String(body.id || '')];
  const ip = req.socket.remoteAddress + '|' + body.id;
  if (!ch || Date.now() - (reportLimit.get(ip) || 0) < 60000) return json(res, 200, { ok: true });
  reportLimit.set(ip, Date.now());
  ch.reports = (ch.reports || 0) + 1; ch.lastReport = Date.now(); ch.lastReportMsg = String(body.message || '').slice(0, 200);
  if (ch.reports >= 2) enqueueCheck([ch.id]);
  save();
  json(res, 200, { ok: true });
}

/* ---------- Arquivos do app ---------- */
const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.png': 'image/png',
  '.svg': 'image/svg+xml', '.m3u': 'audio/x-mpegurl; charset=utf-8', '.webmanifest': 'application/manifest+json', '.ico': 'image/x-icon'
};
function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/' || rel === '') rel = '/index.html';
  if (rel === '/admin') rel = '/admin.html';
  const file = path.normalize(path.join(PUBLIC, rel));
  if (file.indexOf(PUBLIC) !== 0) { res.writeHead(403); return res.end(); }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404); return res.end('Não encontrado'); }
    const ext = path.extname(file);
    res.writeHead(200, {
      'Content-Type': TYPES[ext] || 'application/octet-stream',
      'Content-Length': st.size,
      'Cache-Control': ext === '.png' ? 'public, max-age=604800' : 'no-cache'
    });
    fs.createReadStream(file).pipe(res);
  });
}

const server = http.createServer((req, res) => {
  let u;
  try { u = new URL(req.url, 'http://local'); } catch (e) { res.writeHead(400); return res.end(); }
  if (u.pathname.indexOf('/api/admin') === 0) return adminApi(req, res, u).catch((e) => json(res, 500, { error: e.message }));
  if (u.pathname === '/api/report' && req.method === 'POST') return reportApi(req, res);
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
  if (u.pathname === '/p') return proxy(req, res, u.searchParams);
  if (u.pathname === '/vendor/hls.min.js') return serveHls(res);
  if (u.pathname === '/check') {
    const ok = keyOk(u.searchParams.get('k'));
    res.writeHead(ok ? 200 : 403, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    return res.end(JSON.stringify({ ok }));
  }
  // Playlist combinada (todas as fontes ativas, só canais funcionando). O endereço antigo continua valendo.
  if (u.pathname === '/api/playlist.m3u' || u.pathname === '/listas/brasil-ok.m3u') {
    res.writeHead(200, { 'Content-Type': 'audio/x-mpegurl; charset=utf-8', 'Cache-Control': 'no-cache' });
    return res.end(playlistM3u());
  }
  if (u.pathname === '/listas/status.json') {
    const s = summary();
    return json(res, 200, { checkedAt: new Date(db.lastFullCheck || Date.now()).toISOString(), total: s.total, working: s.byStatus.ok, visible: s.visible, running: progress.running });
  }
  serveStatic(req, res, u.pathname);
});
server.listen(PORT, () => {
  console.log('Meu IPTV rodando na porta ' + PORT);
  console.log('Código de acesso: ' + CFG.accessKey);
});
