/* Comunicação com o servidor IPTV (via servidor intermediário) e com o TMDB */
var Api = (function () {
  let cfg = null;      // { server, user, pass, tmdb, mediaMode }
  let key = '';        // código de acesso do servidor intermediário
  const cache = new Map();

  function setKey(k) { key = k || ''; }
  function getKey() { return key; }
  function setConfig(c) { cfg = c; cache.clear(); }
  function getConfig() { return cfg; }

  /* Passa pelo servidor intermediário */
  function via(url) { return '/p?k=' + encodeURIComponent(key) + '&u=' + encodeURIComponent(url); }

  /* Vídeo e imagens: direto quando o site é http; pelo servidor quando é https (ou se escolhido) */
  function useProxyMedia() {
    const m = (cfg && cfg.mediaMode) || 'auto';
    if (m === 'proxy') return true;
    if (m === 'direct') return false;
    return location.protocol === 'https:';
  }
  function media(url) {
    if (!url) return '';
    if (/^https:\/\/image\.tmdb\.org\//.test(url)) return url;
    if (useProxyMedia() || (location.protocol === 'https:' && /^http:/.test(url))) return via(url);
    return url;
  }

  async function checkKey(k) {
    try {
      const r = await fetch('/check?k=' + encodeURIComponent(k), { cache: 'no-store' });
      return r.ok;
    } catch (e) { return false; }
  }

  async function getJson(url, timeoutMs) {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), timeoutMs || 45000);
    try {
      const r = await fetch(url, { signal: ctl.signal });
      if (r.status === 403) throw new Error('Código de acesso inválido');
      if (r.status === 502) throw new Error('Não foi possível conectar ao servidor IPTV');
      if (!r.ok) throw new Error('Erro do servidor (' + r.status + ')');
      const txt = await r.text();
      try { return JSON.parse(txt); } catch (e) { throw new Error('Resposta inválida do servidor IPTV'); }
    } catch (e) {
      if (e.name === 'AbortError') throw new Error('O servidor demorou demais para responder');
      throw e;
    } finally { clearTimeout(t); }
  }

  /* Aceita "servidor.com:8080", "http://servidor.com:8080/" ou um link M3U completo */
  function parseServerInput(server, user, pass) {
    server = (server || '').trim();
    const m = server.match(/^(https?:\/\/[^\/?#]+)[^?]*\?(.*)$/i);
    if (m && /username=/i.test(m[2])) {
      const q = new URLSearchParams(m[2]);
      return { server: m[1], user: q.get('username') || user, pass: q.get('password') || pass };
    }
    if (server && !/^https?:\/\//i.test(server)) server = 'http://' + server;
    server = server.replace(/\/+$/, '').replace(/\/player_api\.php$/i, '');
    return { server, user: (user || '').trim(), pass: (pass || '').trim() };
  }

  function apiUrl(params) {
    return cfg.server + '/player_api.php?username=' + encodeURIComponent(cfg.user) +
      '&password=' + encodeURIComponent(cfg.pass) + (params ? '&' + params : '');
  }
  async function call(params, useCache = true) {
    const url = apiUrl(params);
    if (useCache && cache.has(url)) return cache.get(url);
    const p = getJson(via(url));
    if (useCache) { cache.set(url, p); p.catch(() => cache.delete(url)); }
    return p;
  }
  function asArray(d) {
    if (!d) return [];
    if (Array.isArray(d)) return d;
    return Object.keys(d).map((k) => d[k]);
  }

  /* ---------- Listas M3U (canais gratuitos ou link próprio) ---------- */
  let m3u = null; // { groups: [], items: [] }
  function isM3u() { return !!(cfg && cfg.type === 'm3u'); }
  function hashId(s) {
    let h = 0;
    for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
    return 'm' + (h >>> 0).toString(36);
  }
  function parseM3u(text) {
    const items = [], groups = [];
    let cur = null;
    text.split(/\r?\n/).forEach((raw) => {
      const l = raw.trim();
      if (l.indexOf('#EXTINF') === 0) {
        const attr = (k) => { const m = l.match(new RegExp(k + '="([^"]*)"')); return m ? m[1] : ''; };
        const comma = l.lastIndexOf(',');
        cur = { name: comma > -1 ? l.slice(comma + 1).trim() : 'Canal', stream_icon: attr('tvg-logo'), group: attr('group-title') || 'Outros', serverId: attr('meu-id') };
      } else if (l && l[0] !== '#' && cur) {
        cur.url = l;
        cur.stream_id = cur.serverId || hashId(cur.name + '|' + cur.group);
        cur.category_id = cur.group;
        if (groups.indexOf(cur.group) < 0) groups.push(cur.group);
        items.push(cur);
        cur = null;
      }
    });
    return { groups, items };
  }
  async function loadM3u() {
    const src = cfg.m3u;
    const url = src[0] === '/' ? src + '?t=' + Date.now() : via(src);
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 60000);
    let r;
    try { r = await fetch(url, { signal: ctl.signal }); }
    catch (e) { throw new Error(e.name === 'AbortError' ? 'A lista demorou demais para carregar' : 'Não foi possível baixar a lista'); }
    finally { clearTimeout(t); }
    if (r.status === 403) throw new Error('Código de acesso inválido');
    if (!r.ok) throw new Error('Erro ao baixar a lista (' + r.status + ')');
    const txt = await r.text();
    if (txt.indexOf('#EXTM3U') < 0) throw new Error('O link não é uma lista M3U válida');
    m3u = parseM3u(txt);
    if (!m3u.items.length) throw new Error('A lista está vazia');
  }

  async function login() {
    if (isM3u()) {
      await loadM3u();
      return { user_info: { auth: 1, status: 'Active', m3u: true }, server_info: {}, total: m3u.items.length };
    }
    const d = await call('', false);
    if (!d || !d.user_info) throw new Error('Servidor não reconheceu a conta');
    if (String(d.user_info.auth) !== '1') throw new Error('Usuário ou senha incorretos');
    if (d.user_info.status && d.user_info.status !== 'Active') throw new Error('Conta ' + d.user_info.status);
    return d;
  }

  const ACT = {
    live: { cats: 'get_live_categories', list: 'get_live_streams' },
    movie: { cats: 'get_vod_categories', list: 'get_vod_streams' },
    series: { cats: 'get_series_categories', list: 'get_series' }
  };
  async function categories(type) {
    if (isM3u()) return type === 'live' ? m3u.groups.map((g) => ({ category_id: g, category_name: g })) : [];
    return asArray(await call('action=' + ACT[type].cats));
  }
  async function streams(type, catId) {
    if (isM3u()) return type === 'live' ? m3u.items.filter((x) => !catId || x.category_id === catId) : [];
    return asArray(await call('action=' + ACT[type].list + (catId ? '&category_id=' + encodeURIComponent(catId) : '')));
  }
  function vodInfo(id) { return call('action=get_vod_info&vod_id=' + id); }
  function seriesInfo(id) { return call('action=get_series_info&series_id=' + id); }
  async function shortEpg(id) {
    if (isM3u()) return [];
    const d = await call('action=get_short_epg&stream_id=' + id + '&limit=3');
    if (!d || !d.epg_listings) return [];
    return asArray(d.epg_listings).map((x) => ({
      title: b64(x.title), desc: b64(x.description),
      start: toDate(x.start_timestamp, x.start), end: toDate(x.stop_timestamp, x.end)
    }));
  }
  function b64(s) {
    if (!s) return '';
    try { return decodeURIComponent(escape(atob(s))); } catch (e) { return s; }
  }
  function toDate(ts, str) {
    if (ts) return new Date(parseInt(ts, 10) * 1000);
    if (str) return new Date(String(str).replace(' ', 'T'));
    return null;
  }

  /* URLs de reprodução (o Safari toca HLS: .m3u8) */
  const enc = encodeURIComponent;
  function liveUrl(s) { if (s.url) return media(s.url); return media(cfg.server + '/live/' + enc(cfg.user) + '/' + enc(cfg.pass) + '/' + s.stream_id + '.m3u8'); }
  function movieUrl(id, ext) { return media(cfg.server + '/movie/' + enc(cfg.user) + '/' + enc(cfg.pass) + '/' + id + '.' + (ext || 'mp4')); }
  function episodeUrl(ep) { return media(cfg.server + '/series/' + enc(cfg.user) + '/' + enc(cfg.pass) + '/' + ep.id + '.' + (ep.container_extension || 'mp4')); }

  /* ---------- TMDB (opcional) ---------- */
  function tmdbOn() { return !!(cfg && cfg.tmdb); }
  async function tmdbGet(path) {
    const url = 'https://api.themoviedb.org/3' + path + (path.indexOf('?') > -1 ? '&' : '?') +
      'api_key=' + encodeURIComponent(cfg.tmdb) + '&language=pt-BR';
    if (cache.has(url)) return cache.get(url);
    const p = getJson(url, 15000);
    cache.set(url, p); p.catch(() => cache.delete(url));
    return p;
  }
  async function tmdbDetails(kind, tmdbId, name, year) {
    if (!tmdbOn()) return null;
    let id = tmdbId && String(tmdbId) !== '0' ? tmdbId : null;
    if (!id) {
      const q = cleanTitle(name);
      if (!q) return null;
      const s = await tmdbGet('/search/' + kind + '?query=' + encodeURIComponent(q) +
        (year ? (kind === 'movie' ? '&year=' : '&first_air_date_year=') + year : ''));
      if (!s || !s.results || !s.results.length) return null;
      id = s.results[0].id;
    }
    return tmdbGet('/' + kind + '/' + id + '?append_to_response=credits');
  }
  function tmdbImg(p, size) { return p ? 'https://image.tmdb.org/t/p/' + (size || 'w500') + p : ''; }

  function cleanTitle(n) {
    if (!n) return '';
    return String(n)
      .replace(/^[A-Z]{2,3}\s*[|:\-]\s*/, '')
      .replace(/\[[^\]]*\]|\([^)]*\)/g, ' ')
      .replace(/\b(4K|UHD|FHD|HD|SD|H265|HEVC|LEG|DUB|DUAL|LEGENDADO|DUBLADO|NACIONAL)\b/gi, ' ')
      .replace(/[|_]+/g, ' ')
      .replace(/\s+/g, ' ').trim();
  }
  function yearOf(n) {
    const m = String(n || '').match(/\((\d{4})\)|\b(19\d{2}|20\d{2})\b/);
    return m ? (m[1] || m[2]) : '';
  }

  return {
    setKey, getKey, checkKey, setConfig, getConfig, parseServerInput, isM3u,
    login, categories, streams, vodInfo, seriesInfo, shortEpg,
    liveUrl, movieUrl, episodeUrl, media,
    tmdbOn, tmdbDetails, tmdbImg, cleanTitle, yearOf, asArray
  };
})();
