/* Painel administrativo do Meu IPTV: fontes, canais, verificação e problemas */
(function () {
  'use strict';
  const app = document.getElementById('app');
  const KEY_STORE = 'meuiptv.key';
  let key = '';
  try { key = JSON.parse(localStorage.getItem(KEY_STORE) || '""'); } catch (e) {}
  const urlKey = new URLSearchParams(location.search).get('k');
  if (urlKey) key = urlKey;

  let S = null;              // resumo vindo do servidor
  let tab = 'overview';
  let pollTimer = null;
  const chFilter = { q: '', status: '', source: '', category: '', offset: 0 };

  /* ---------- utilidades ---------- */
  function h(tag, attrs, kids) {
    const el = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      const v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'html') el.innerHTML = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    }
    (kids || []).forEach((c) => { if (c != null && c !== false) el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return el;
  }
  const clear = (el) => { while (el.firstChild) el.removeChild(el.firstChild); };
  let toastT;
  function toast(t, bad) {
    const el = document.getElementById('toast');
    el.textContent = t; el.className = 'toast on' + (bad ? ' bad' : '');
    clearTimeout(toastT); toastT = setTimeout(() => { el.className = 'toast'; }, 3200);
  }
  function ago(ts) {
    if (!ts) return 'nunca';
    const s = Math.round((Date.now() - ts) / 1000);
    if (s < 60) return 'agora';
    if (s < 3600) return 'há ' + Math.round(s / 60) + ' min';
    if (s < 86400) return 'há ' + Math.round(s / 3600) + ' h';
    return 'há ' + Math.round(s / 86400) + ' dias';
  }
  async function api(method, path, body) {
    const r = await fetch('/api/admin/' + path, {
      method, headers: { 'X-Key': key, 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined, cache: 'no-store'
    });
    let j = {};
    try { j = await r.json(); } catch (e) {}
    if (r.status === 403) { logout(); throw new Error('Código de acesso inválido'); }
    if (!r.ok) { const e = new Error(j.error || 'Erro ' + r.status); e.data = j; throw e; }
    return j;
  }
  const STATUS = { ok: ['Funcionando', 'ok'], down: ['Fora do ar', 'down'], incompatible: ['Incompatível', 'warn'], drm: ['DRM', 'drm'], unknown: ['Não verificado', 'unk'] };
  const badge = (st) => h('span', { class: 'badge ' + (STATUS[st] || STATUS.unknown)[1], text: (STATUS[st] || STATUS.unknown)[0] });
  const KIND = { builtin: 'Lista embutida', url: 'Link (URL)', file: 'Arquivo', manual: 'Manual' };

  /* ---------- acesso ---------- */
  function logout() { key = ''; try { localStorage.removeItem(KEY_STORE); } catch (e) {} renderLogin('Informe o código de acesso.'); }
  function renderLogin(msg) {
    clear(app);
    const inp = h('input', { type: 'text', placeholder: 'Código de acesso', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false', value: key });
    const m = h('p', { class: 'msg', text: msg || '' });
    app.appendChild(h('div', { class: 'login' }, [
      h('h1', { text: 'Painel do Meu IPTV' }),
      h('p', { class: 'muted', text: 'Gerencie fontes, canais e a verificação automática.' }),
      h('form', { onsubmit: async (e) => {
        e.preventDefault(); key = inp.value.trim();
        try { await load(); try { localStorage.setItem(KEY_STORE, JSON.stringify(key)); } catch (x) {} render(); }
        catch (err) { m.textContent = err.message; }
      } }, [inp, h('button', { class: 'btn primary', type: 'submit', text: 'Entrar' })]),
      m
    ]));
  }

  async function load() { S = await api('GET', 'summary'); return S; }

  /* ---------- estrutura ---------- */
  const TABS = [['overview', 'Visão geral'], ['sources', 'Fontes'], ['channels', 'Canais'], ['problems', 'Problemas'], ['settings', 'Ajustes']];
  let body;
  function render() {
    clear(app);
    const nav = h('nav', { class: 'tabs' }, TABS.map(([id, label]) => h('button', {
      class: 'tab' + (tab === id ? ' active' : ''), onclick: () => { tab = id; render(); }
    }, [label, id === 'problems' && S && S.problems ? h('i', { class: 'dot', text: String(S.problems) }) : null])));
    body = h('main', { class: 'body' });
    app.appendChild(h('header', { class: 'top' }, [
      h('div', { class: 'brand' }, [h('div', { class: 'mark' }), h('div', null, [h('b', { text: 'Meu IPTV' }), h('span', { text: 'Painel administrativo' })])]),
      h('a', { class: 'btn ghost', href: '/', text: 'Abrir o app' })
    ]));
    app.appendChild(nav);
    app.appendChild(body);
    ({ overview: renderOverview, sources: renderSources, channels: renderChannels, problems: renderProblems, settings: renderSettings })[tab]();
    schedulePoll();
  }
  function schedulePoll() {
    clearTimeout(pollTimer);
    const busy = S && (S.progress.running || S.sources.some((s) => s.refreshing));
    pollTimer = setTimeout(async () => {
      try {
        const was = S;
        await load();
        if (tab === 'overview' || (was && was.progress.running !== S.progress.running) || tab === 'sources') render();
        else schedulePoll();
      } catch (e) { schedulePoll(); }
    }, busy ? 2500 : 15000);
  }

  /* ---------- Visão geral ---------- */
  function renderOverview() {
    const b = S.byStatus, p = S.progress;
    const card = (n, label, cls, st) => h('button', { class: 'stat ' + cls, onclick: () => { tab = 'channels'; Object.assign(chFilter, { status: st || '', offset: 0 }); render(); } },
      [h('b', { text: String(n) }), h('span', { text: label })]);
    body.appendChild(h('div', { class: 'stats' }, [
      card(S.visible, 'No app agora', 'accent', ''), card(b.ok, 'Funcionando', 'ok', 'ok'), card(b.down, 'Fora do ar', 'down', 'down'),
      card(b.incompatible, 'Incompatíveis', 'warn', 'incompatible'), card(b.drm, 'Com DRM', 'drm', 'drm'), card(b.unknown, 'Não verificados', 'unk', 'unknown')
    ]));
    const pct = p.total ? Math.round(p.done / p.total * 100) : 0;
    body.appendChild(h('section', { class: 'panel' }, [
      h('h2', { text: 'Verificação de disponibilidade' }),
      h('p', { class: 'muted', text: p.running
        ? 'Verificando ' + p.done + ' de ' + p.total + ' canais…'
        : 'Última verificação completa: ' + ago(S.lastFullCheck) + '. Automática a cada ' + S.settings.checkHours + ' h.' }),
      p.running ? h('div', { class: 'bar' }, [h('i', { style: 'width:' + pct + '%' })]) : null,
      h('div', { class: 'row' }, [
        h('button', { class: 'btn primary', disabled: p.running, onclick: () => act(() => api('POST', 'check', { scope: 'all' }), 'Verificação iniciada') }, ['Verificar todos']),
        h('button', { class: 'btn', disabled: p.running, onclick: () => act(() => api('POST', 'check', { scope: 'failed' }), 'Reverificando os que falharam') }, ['Reverificar os com falha']),
        h('button', { class: 'btn danger', onclick: removeInvalid }, ['Remover links inválidos'])
      ])
    ]));
    body.appendChild(h('section', { class: 'panel' }, [
      h('h2', { text: 'Fontes' }),
      h('div', { class: 'list' }, S.sources.map((s) => h('div', { class: 'item' }, [
        h('div', { class: 'grow' }, [h('b', { text: s.name }), h('small', { text: KIND[s.kind] + ' · ' + s.ok + ' de ' + s.total + ' funcionando' + (s.enabled === false ? ' · desativada' : '') })]),
        s.lastError ? h('span', { class: 'badge down', text: 'erro' }) : null
      ])))
    ]));
  }
  async function act(fn, okMsg) {
    try { await fn(); if (okMsg) toast(okMsg); await load(); render(); }
    catch (e) { toast(e.message, true); }
  }
  async function removeInvalid() {
    const n = S.byStatus.down + S.byStatus.incompatible + S.byStatus.drm;
    if (!n) return toast('Não há links inválidos');
    if (!confirm('Remover ' + n + ' canais fora do ar, incompatíveis ou com DRM?\n\nOs canais de listas continuam removidos mesmo quando a lista for atualizada (dá para restaurar em Canais › Removidos).')) return;
    act(() => api('POST', 'channels/remove-invalid', {}), n + ' canais removidos');
  }

  /* ---------- Fontes ---------- */
  function renderSources() {
    // adicionar
    let mode = 'url';
    const forms = h('div');
    const modes = h('div', { class: 'seg' }, [['url', 'Playlist por link'], ['file', 'Arquivo do aparelho'], ['stream', 'Stream único']].map(([id, label]) =>
      h('button', { class: id === mode ? 'active' : '', onclick: (e) => { mode = id; modes.querySelectorAll('button').forEach((b) => b.classList.toggle('active', b === e.currentTarget)); drawForm(); } }, [label])));
    function drawForm() {
      clear(forms);
      if (mode === 'url') {
        const name = h('input', { placeholder: 'Nome (opcional)' });
        const url = h('input', { placeholder: 'https://exemplo.com/lista.m3u', inputmode: 'url', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
        const auto = h('input', { type: 'checkbox', checked: true });
        const every = select([1, 3, 6, 12, 24, 48].map((x) => [x, 'a cada ' + x + ' h']), 12);
        const btn = h('button', { class: 'btn primary', type: 'submit', text: 'Adicionar playlist' });
        forms.appendChild(h('form', { class: 'form', onsubmit: async (e) => {
          e.preventDefault(); btn.disabled = true; btn.textContent = 'Baixando a lista…';
          try {
            const s = await api('POST', 'sources', { kind: 'url', name: name.value, url: url.value, autoUpdate: auto.checked, intervalHours: +every.value });
            toast('Fonte adicionada: ' + s.count + ' canais. Verificação iniciada.'); await load(); render();
          } catch (err) { toast(err.message, true); btn.disabled = false; btn.textContent = 'Adicionar playlist'; }
        } }, [field('Endereço da playlist M3U/M3U8', url), field('Nome', name),
          h('label', { class: 'check' }, [auto, ' Atualizar automaticamente ', every]), btn]));
      } else if (mode === 'file') {
        const name = h('input', { placeholder: 'Nome (opcional)' });
        const file = h('input', { type: 'file', accept: '.m3u,.m3u8,audio/x-mpegurl,application/vnd.apple.mpegurl,text/plain' });
        const btn = h('button', { class: 'btn primary', type: 'submit', text: 'Importar arquivo' });
        forms.appendChild(h('form', { class: 'form', onsubmit: async (e) => {
          e.preventDefault();
          const f = file.files[0];
          if (!f) return toast('Escolha um arquivo .m3u ou .m3u8', true);
          if (f.size > 40 * 1024 * 1024) return toast('Arquivo grande demais (máx. 40 MB)', true);
          btn.disabled = true; btn.textContent = 'Importando…';
          try {
            const content = await f.text();
            const s = await api('POST', 'sources', { kind: 'file', name: name.value, fileName: f.name, content });
            toast('Arquivo importado: ' + s.count + ' canais'); await load(); render();
          } catch (err) { toast(err.message, true); btn.disabled = false; btn.textContent = 'Importar arquivo'; }
        } }, [field('Arquivo M3U/M3U8', file), field('Nome', name), btn]));
      } else {
        const url = h('input', { placeholder: 'https://…/canal.m3u8', inputmode: 'url', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
        const name = h('input', { placeholder: 'Nome do canal' });
        const logo = h('input', { placeholder: 'Endereço do logotipo (opcional)', inputmode: 'url', autocapitalize: 'off' });
        const cat = select(S.categories.map((c) => [c, c]), 'Outros');
        const out = h('div', { class: 'detect' });
        const detectBtn = h('button', { class: 'btn', type: 'button', text: 'Identificar formato', onclick: async () => {
          if (!url.value.trim()) return;
          out.textContent = 'Testando…';
          try {
            const d = await api('POST', 'detect', { url: url.value.trim() });
            clear(out); out.appendChild(badge(d.status)); out.appendChild(document.createTextNode(' ' + d.format.toUpperCase() + ' — ' + d.detail));
          } catch (err) { out.textContent = err.message; }
        } });
        const btn = h('button', { class: 'btn primary', type: 'submit', text: 'Cadastrar canal' });
        forms.appendChild(h('form', { class: 'form', onsubmit: async (e) => {
          e.preventDefault(); btn.disabled = true;
          try {
            const c = await api('POST', 'channels', { url: url.value, name: name.value, logo: logo.value, category: cat.value });
            toast('Canal cadastrado: ' + c.statusText + (c.detail ? ' (' + c.detail + ')' : '')); await load(); render();
          } catch (err) {
            if (err.data && err.data.playlist) { toast('É uma playlist: use "Playlist por link"', true); mode = 'url'; }
            else toast(err.message, true);
            btn.disabled = false;
          }
        } }, [field('Endereço do stream', url), h('div', { class: 'row' }, [detectBtn, out]), field('Nome', name), field('Categoria', cat), field('Logotipo', logo), btn]));
      }
    }
    drawForm();
    body.appendChild(h('section', { class: 'panel' }, [h('h2', { text: 'Adicionar fonte' }),
      h('p', { class: 'muted', text: 'Use apenas transmissões gratuitas autorizadas ou fontes que você tem permissão para acessar. Conteúdo com DRM só funciona no app oficial do serviço.' }),
      modes, forms]));

    // lista
    body.appendChild(h('section', { class: 'panel' }, [h('h2', { text: 'Fontes cadastradas' }),
      h('div', { class: 'list' }, S.sources.map(sourceRow))]));
  }
  function sourceRow(s) {
    const auto = h('input', { type: 'checkbox', checked: !!s.autoUpdate, disabled: s.kind === 'manual' || s.kind === 'file',
      onchange: (e) => act(() => api('PUT', 'sources/' + s.id, { autoUpdate: e.target.checked }), 'Salvo') });
    const en = h('input', { type: 'checkbox', checked: s.enabled !== false, onchange: (e) => act(() => api('PUT', 'sources/' + s.id, { enabled: e.target.checked }), e.target.checked ? 'Fonte ativada' : 'Fonte desativada (some do app)') });
    const every = select([1, 3, 6, 12, 24, 48, 168].map((x) => [x, x < 168 ? x + ' h' : '1 semana']), s.intervalHours || 12);
    every.onchange = () => act(() => api('PUT', 'sources/' + s.id, { intervalHours: +every.value }), 'Intervalo salvo');
    return h('div', { class: 'source' }, [
      h('div', { class: 'src-head' }, [
        h('div', { class: 'grow' }, [h('b', { text: s.name }), h('small', { text: KIND[s.kind] + (s.url ? ' · ' + s.url : '') + (s.fileName ? ' · ' + s.fileName : '') })]),
        s.refreshing ? h('span', { class: 'badge unk', text: 'atualizando…' }) : null
      ]),
      h('div', { class: 'src-meta' }, [
        h('span', { text: s.ok + ' de ' + s.total + ' funcionando' }),
        h('span', { text: 'Atualizada ' + ago(s.lastFetch) }),
        s.lastError ? h('span', { class: 'err', text: 'Erro: ' + s.lastError }) : null
      ]),
      h('div', { class: 'row wrap' }, [
        h('label', { class: 'check' }, [en, ' Ativa']),
        s.kind === 'url' || s.kind === 'builtin' ? h('label', { class: 'check' }, [auto, ' Atualização automática ', every]) : null,
        s.kind !== 'manual' ? h('button', { class: 'btn small', onclick: () => act(() => api('POST', 'sources/' + s.id + '/refresh'), 'Atualizando a fonte') }, ['Atualizar agora']) : null,
        h('button', { class: 'btn small', onclick: () => act(() => api('POST', 'sources/' + s.id + '/check'), 'Verificando os canais da fonte') }, ['Verificar canais']),
        h('button', { class: 'btn small', onclick: () => { tab = 'channels'; Object.assign(chFilter, { source: s.id, status: '', offset: 0 }); render(); } }, ['Ver canais']),
        s.kind === 'url' || s.kind === 'file' ? h('button', { class: 'btn small danger', onclick: () => {
          if (confirm('Apagar a fonte "' + s.name + '" e seus ' + s.total + ' canais?')) act(() => api('DELETE', 'sources/' + s.id), 'Fonte apagada');
        } }, ['Apagar']) : null
      ])
    ]);
  }
  function field(label, input) { return h('label', { class: 'field' }, [h('span', { text: label }), input]); }
  function select(opts, val) {
    const s = h('select', null, opts.map(([v, l]) => h('option', { value: String(v), text: l })));
    s.value = String(val);
    return s;
  }

  /* ---------- Canais ---------- */
  async function renderChannels() {
    const q = h('input', { type: 'search', placeholder: 'Buscar por nome ou endereço', value: chFilter.q });
    let qt; q.addEventListener('input', () => { clearTimeout(qt); qt = setTimeout(() => { chFilter.q = q.value; chFilter.offset = 0; loadList(); }, 350); });
    const st = select([['', 'Todos os status'], ['ok', 'Funcionando'], ['down', 'Fora do ar'], ['incompatible', 'Incompatíveis'], ['drm', 'Com DRM'],
      ['unknown', 'Não verificados'], ['problems', 'Com relatos de falha'], ['hidden', 'Ocultos'], ['removed', 'Removidos']], chFilter.status);
    const so = select([['', 'Todas as fontes']].concat(S.sources.map((s) => [s.id, s.name])), chFilter.source);
    const ca = select([['', 'Todas as categorias']].concat(S.categories.map((c) => [c, c])), chFilter.category);
    [st, so, ca].forEach((el, i) => el.onchange = () => { chFilter[['status', 'source', 'category'][i]] = el.value; chFilter.offset = 0; loadList(); });
    const list = h('div', { class: 'chlist' });
    const pager = h('div', { class: 'pager' });
    body.appendChild(h('section', { class: 'panel' }, [
      h('div', { class: 'filters' }, [q, st, so, ca]),
      list, pager
    ]));
    async function loadList() {
      list.textContent = 'Carregando…';
      const qs = new URLSearchParams({ q: chFilter.q, status: chFilter.status, source: chFilter.source, category: chFilter.category, offset: chFilter.offset, limit: 60 });
      try {
        const r = await api('GET', 'channels?' + qs);
        clear(list); clear(pager);
        if (!r.items.length) { list.appendChild(h('p', { class: 'muted', text: 'Nenhum canal com esses filtros.' })); return; }
        r.items.forEach((c) => list.appendChild(channelRow(c, loadList)));
        const page = Math.floor(chFilter.offset / 60) + 1, pages = Math.ceil(r.total / 60);
        pager.appendChild(h('span', { text: r.total + ' canais · página ' + page + ' de ' + pages }));
        if (page > 1) pager.appendChild(h('button', { class: 'btn small', onclick: () => { chFilter.offset -= 60; loadList(); } }, ['‹ Anterior']));
        if (page < pages) pager.appendChild(h('button', { class: 'btn small', onclick: () => { chFilter.offset += 60; loadList(); } }, ['Próxima ›']));
      } catch (e) { list.textContent = e.message; }
    }
    loadList();
  }
  function channelRow(c, reload) {
    const e = c.edited || {};
    const name = e.name || c.name, cat = e.category || c.category, logo = e.logo || c.logo;
    const row = h('div', { class: 'ch' + (c.hidden ? ' hidden-ch' : '') }, [
      h('div', { class: 'logo' }, [logo ? h('img', { src: logo, alt: '', loading: 'lazy', onerror: (ev) => ev.target.remove() }) : null]),
      h('div', { class: 'grow' }, [
        h('div', { class: 'ch-name' }, [name, c.hidden ? h('em', { text: ' (oculto)' }) : null, e.name || e.category || e.url || e.logo ? h('em', { text: ' · editado' }) : null]),
        h('small', { text: cat + ' · ' + c.source + (c.format ? ' · ' + c.format.toUpperCase() : '') }),
        h('div', { class: 'ch-st' }, [badge(c.status), c.detail ? h('small', { text: ' ' + c.detail }) : null,
          c.reports ? h('span', { class: 'badge down', text: c.reports + ' relato(s) de falha' }) : null,
          h('small', { class: 'when', text: ' · verificado ' + ago(c.lastCheck) })])
      ]),
      h('div', { class: 'acts' }, c.removed
        ? [h('button', { class: 'btn small', onclick: () => act(() => api('PUT', 'channels/' + c.id, { removed: false }), 'Canal restaurado').then(reload) }, ['Restaurar'])]
        : [
          h('button', { class: 'icon', title: 'Testar reprodução', onclick: () => preview(c) }, ['▶']),
          h('button', { class: 'icon', title: 'Verificar agora', onclick: async (ev) => {
            ev.target.disabled = true; ev.target.textContent = '…';
            try { const n = await api('POST', 'channels/' + c.id + '/check'); toast(name + ': ' + n.statusText + (n.detail ? ' — ' + n.detail : '')); reload(); }
            catch (err) { toast(err.message, true); }
          } }, ['↻']),
          h('button', { class: 'icon', title: 'Editar', onclick: () => edit(c, reload) }, ['✎']),
          h('button', { class: 'icon danger', title: 'Remover', onclick: () => { if (confirm('Remover "' + name + '"?')) act(() => api('DELETE', 'channels/' + c.id), 'Canal removido').then(reload); } }, ['✕'])
        ])
    ]);
    return row;
  }

  function modal(title, content, onClose) {
    const back = h('div', { class: 'modal-back', onclick: (e) => { if (e.target === back) close(); } });
    const box = h('div', { class: 'modal' }, [h('div', { class: 'modal-head' }, [h('b', { text: title }), h('button', { class: 'icon', onclick: () => close() }, ['✕'])]), content]);
    back.appendChild(box);
    document.body.appendChild(back);
    function close() { if (onClose) onClose(); back.remove(); }
    return close;
  }
  function edit(c, reload) {
    const e = c.edited || {};
    const name = h('input', { value: e.name || c.name });
    const cat = select(S.categories.map((x) => [x, x]), e.category || c.category);
    const logo = h('input', { value: e.logo || c.logo || '', inputmode: 'url', autocapitalize: 'off' });
    const url = h('input', { value: e.url || c.url, inputmode: 'url', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
    const hidden = h('input', { type: 'checkbox', checked: c.hidden });
    const reset = h('button', { class: 'btn small', type: 'button', text: 'Desfazer edições', onclick: async () => {
      try { await api('PUT', 'channels/' + c.id, { name: c.name, category: c.category, logo: c.logo || '', url: c.url, resetReports: true }); toast('Edições desfeitas'); close(); reload(); }
      catch (err) { toast(err.message, true); }
    } });
    const close = modal('Editar canal', h('form', { class: 'form', onsubmit: async (ev) => {
      ev.preventDefault();
      try {
        await api('PUT', 'channels/' + c.id, { name: name.value, category: cat.value, logo: logo.value, url: url.value, hidden: hidden.checked, resetReports: true });
        toast('Canal salvo'); close(); reload();
      } catch (err) { toast(err.message, true); }
    } }, [
      field('Nome', name), field('Categoria', cat), field('Logotipo (URL)', logo), field('Endereço do stream', url),
      h('label', { class: 'check' }, [hidden, ' Ocultar do app']),
      h('p', { class: 'muted small', text: 'Original: ' + c.name + ' — ' + c.url + (c.manual ? '' : '. As edições são mantidas quando a lista é atualizada.') }),
      h('div', { class: 'row' }, [h('button', { class: 'btn primary', type: 'submit', text: 'Salvar' }), reset])
    ]));
  }
  function preview(c) {
    const e = c.edited || {};
    const url = e.url || c.playUrl || c.url;
    const video = h('video', { controls: true, playsinline: true, autoplay: true, 'x-webkit-airplay': 'allow' });
    const info = h('p', { class: 'muted small', text: 'Carregando…' });
    let player = null, reported = false;
    const close = modal(e.name || c.name, h('div', null, [video, info, h('p', { class: 'muted small', text: url })]), () => { if (player) player.destroy(); });
    player = PlayerCore.attach(video, url, { key, onPlaying: () => { info.textContent = 'Reproduzindo (' + player.engine() + ')'; },
      onError: (msg) => {
        info.textContent = msg + (c.format ? ' · formato detectado: ' + c.format.toUpperCase() : '');
        if (!reported) { reported = true; fetch('/api/report', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: c.id, message: msg }) }).catch(() => {}); }
      } });
    return close;
  }

  /* ---------- Problemas ---------- */
  async function renderProblems() {
    body.appendChild(h('section', { class: 'panel' }, [h('h2', { text: 'Problemas de reprodução' }),
      h('p', { class: 'muted', text: 'Canais em que o player relatou falha, além dos que estão fora do ar. Relatos repetidos disparam uma nova verificação automática.' })]));
    const box = h('div', { class: 'chlist' });
    body.lastChild.appendChild(box);
    const reload = async () => {
      box.textContent = 'Carregando…';
      try {
        const [rep, down] = await Promise.all([api('GET', 'channels?status=problems&limit=200'), api('GET', 'channels?status=down&limit=200')]);
        clear(box);
        const seen = new Set();
        const all = rep.items.concat(down.items).filter((c) => !seen.has(c.id) && seen.add(c.id));
        all.sort((a, b) => (b.reports - a.reports) || (b.lastReport - a.lastReport));
        if (!all.length) box.appendChild(h('p', { class: 'muted', text: 'Nenhum problema no momento. 🎉' }));
        all.forEach((c) => box.appendChild(channelRow(c, reload)));
      } catch (e) { box.textContent = e.message; }
    };
    reload();
  }

  /* ---------- Ajustes ---------- */
  function renderSettings() {
    const show = h('input', { type: 'checkbox', checked: S.settings.showUnchecked, onchange: (e) => act(() => api('PUT', 'settings', { showUnchecked: e.target.checked }), 'Salvo') });
    const hrs = select([1, 3, 6, 12, 24].map((x) => [x, 'a cada ' + x + ' h']), S.settings.checkHours);
    hrs.onchange = () => act(() => api('PUT', 'settings', { checkHours: +hrs.value }), 'Salvo');
    body.appendChild(h('section', { class: 'panel' }, [
      h('h2', { text: 'Ajustes' }),
      h('label', { class: 'check' }, [show, ' Mostrar no app canais ainda não verificados (novas fontes aparecem na hora)']),
      h('label', { class: 'field' }, [h('span', { text: 'Verificação automática de todos os canais' }), hrs]),
      h('p', { class: 'muted small', text: 'O app mostra só canais funcionando (ou não verificados, se marcado acima), de fontes ativas e não ocultos. Favoritos e configurações ficam no aparelho de cada pessoa e são preservados nas atualizações das listas, porque cada canal mantém o mesmo identificador.' }),
      h('button', { class: 'btn', onclick: logout }, ['Sair do painel'])
    ]));
  }

  /* ---------- início ---------- */
  if (key) load().then(() => { try { localStorage.setItem(KEY_STORE, JSON.stringify(key)); } catch (e) {} render(); }).catch((e) => renderLogin(e.message));
  else renderLogin();
})();
