/* Reprodução universal: HLS nativo (Safari/iPhone), hls.js (Chrome, Android, PC) ou arquivo direto (MP4).
 * Usado pelo app e pelo painel. */
var PlayerCore = (function () {
  'use strict';
  let hlsPromise = null;

  function nativeHls(video) {
    return !!video.canPlayType('application/vnd.apple.mpegurl');
  }
  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src; s.async = true;
      s.onload = () => (window.Hls ? resolve(window.Hls) : reject(new Error('hls.js indisponível')));
      s.onerror = () => reject(new Error('Falha ao carregar ' + src));
      document.head.appendChild(s);
    });
  }
  function loadHls() {
    if (window.Hls) return Promise.resolve(window.Hls);
    hlsPromise = hlsPromise || loadScript('/vendor/hls.min.js')
      .catch(() => loadScript('https://cdn.jsdelivr.net/npm/hls.js@1.5.13/dist/hls.min.js'))
      .catch(() => loadScript('https://cdnjs.cloudflare.com/ajax/libs/hls.js/1.5.13/hls.min.js'))
      .catch((e) => { hlsPromise = null; throw e; });
    return hlsPromise;
  }
  function isHlsUrl(url) { return /\.m3u8?(\?|$)/i.test(url) || /\/p\?.*m3u8/i.test(decodeURIComponent(url)); }

  /* Passa pelo servidor (evita bloqueio CORS no hls.js). Com código = qualquer endereço; sem código = só canais cadastrados. */
  function viaServer(url, key) {
    if (!url || url.indexOf('/p?') === 0 || url[0] === '/') return url;
    return '/p?' + (key ? 'k=' + encodeURIComponent(key) + '&' : '') + 'u=' + encodeURIComponent(url);
  }

  /* Liga um <video> a um endereço. Retorna um objeto com destroy().
   * opts: { key, forceProxy, onError(msg, fatal), onPlaying() } */
  function attach(video, url, opts) {
    opts = opts || {};
    let hls = null, destroyed = false, triedProxy = false;
    const fail = (msg) => { if (!destroyed && opts.onError) opts.onError(msg); };
    video.addEventListener('playing', () => { if (opts.onPlaying) opts.onPlaying(); }, { once: true });

    function playNative(src) {
      video.src = src;
      const p = video.play(); if (p && p.catch) p.catch(() => {});
    }
    function startHlsJs(src) {
      loadHls().then((Hls) => {
        if (destroyed) return;
        if (!Hls.isSupported()) { playNative(src); return; }
        hls = new Hls({ enableWorker: true, lowLatencyMode: false, backBufferLength: 30, manifestLoadingMaxRetry: 2, levelLoadingMaxRetry: 2 });
        hls.on(Hls.Events.ERROR, (ev, data) => {
          if (!data.fatal) return;
          const net = data.type === Hls.ErrorTypes.NETWORK_ERROR;
          // Primeira falha de rede direta: tenta de novo passando pelo servidor (CORS)
          if (net && !triedProxy && src.indexOf('/p?') !== 0) {
            triedProxy = true;
            hls.destroy(); hls = null;
            startHlsJs(viaServer(url, opts.key));
            return;
          }
          if (data.type === Hls.ErrorTypes.MEDIA_ERROR && !hls._recovered) { hls._recovered = true; hls.recoverMediaError(); return; }
          fail(net ? 'O canal não respondeu (rede/CORS)' : data.type === Hls.ErrorTypes.MEDIA_ERROR ? 'Formato de vídeo não suportado' : 'Erro do player: ' + data.details);
        });
        hls.loadSource(src);
        hls.attachMedia(video);
        hls.on(Hls.Events.MANIFEST_PARSED, () => { const p = video.play(); if (p && p.catch) p.catch(() => {}); });
      }).catch(() => playNative(src));
    }

    video.onerror = () => {
      if (hls) return;
      const code = video.error ? video.error.code : 0;
      fail(code === 4 ? 'Formato não suportado neste aparelho' : code === 2 ? 'Falha de rede ao carregar o vídeo' : 'Não foi possível reproduzir');
    };

    const wantHls = opts.isHls != null ? opts.isHls : isHlsUrl(url);
    const start = opts.forceProxy ? viaServer(url, opts.key) : url;
    if (wantHls && !nativeHls(video)) startHlsJs(start);
    else playNative(start);

    return {
      engine: () => (hls ? 'hls.js' : (wantHls ? 'HLS nativo' : 'direto')),
      destroy() {
        destroyed = true;
        if (hls) { try { hls.destroy(); } catch (e) {} hls = null; }
        video.onerror = null;
        try { video.pause(); } catch (e) {}
        video.removeAttribute('src');
        try { video.load(); } catch (e) {}
      }
    };
  }

  return { attach, loadHls, nativeHls, viaServer, isHlsUrl };
})();
