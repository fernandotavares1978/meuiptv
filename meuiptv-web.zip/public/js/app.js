/* Meu IPTV — app para iPhone e iPad */
(function () {
  'use strict';
  const app = document.getElementById('app');
  const CHUNK = 60;
  let account = null;
  let section = Store.get('lastSection', 'live');

  /* ================= Utilidades ================= */
  function h(tag, attrs, children) {
    const el = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      const v = attrs[k];
      if (v === null || v === undefined || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'html') el.innerHTML = v;
      else if (k === 'style') el.setAttribute('style', v);
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    }
    (children || []).forEach((c) => {
      if (c === null || c === undefined || c === false) return;
      el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
    return el;
  }
  function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); }
  function initials(s) {
    const w = Api.cleanTitle(s || '').split(' ').filter(Boolean);
    return ((w[0] || '?')[0] + (w[1] ? w[1][0] : '')).toUpperCase();
  }
  function img(src, cls, label) {
    const ph = h('div', { class: cls + ' ph' }, [h('span', { text: initials(label) })]);
    if (!src) return ph;
    const im = h('img', { class: cls, alt: '', loading: 'lazy', decoding: 'async' });
    im.onerror = () => { if (im.parentNode) im.parentNode.replaceChild(ph, im); };
    im.src = Api.media(src);
    return im;
  }
  let toastTimer;
  function toast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('on'), 2600);
  }
  const pad = (n) => (n < 10 ? '0' : '') + n;
  const hhmm = (d) => (d ? pad(d.getHours()) + ':' + pad(d.getMinutes()) : '');
  function clockTime(sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    const hh = Math.floor(sec / 3600), mm = Math.floor((sec % 3600) / 60), ss = sec % 60;
    return (hh ? hh + ':' + pad(mm) : mm) + ':' + pad(ss);
  }
  function minutes(sec) {
    sec = parseInt(sec, 10);
    if (!sec) return '';
    const hh = Math.floor(sec / 3600), mm = Math.round((sec % 3600) / 60);
    return hh ? hh + 'h ' + pad(mm) + 'min' : mm + ' min';
  }
  function rating(r) {
    let n = parseFloat(r);
    if (!n || isNaN(n)) return '';
    if (n > 10) n = n / 10;
    return n.toFixed(1);
  }
  function dateBR(ts) {
    if (!ts || ts === 'null') return 'Ilimitado';
    const d = new Date(parseInt(ts, 10) * 1000);
    return pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + d.getFullYear();
  }
  function norm(s) {
    return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  }
  const ICON = {
    back: '<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    airplay: '<svg viewBox="0 0 24 24"><path d="M5 17H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-1" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M12 15l5 6H7z" fill="currentColor"/></svg>',
    live: '<svg viewBox="0 0 24 24"><rect x="2" y="6" width="20" height="14" rx="3" fill="none" stroke="currentColor" stroke-width="2"/><path d="M8 2l4 4 4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    movie: '<svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="3" fill="none" stroke="currentColor" stroke-width="2"/><path d="M7 3v18M17 3v18M3 8h4M3 16h4M17 8h4M17 16h4" stroke="currentColor" stroke-width="2"/></svg>',
    series: '<svg viewBox="0 0 24 24"><rect x="3" y="7" width="18" height="13" rx="3" fill="none" stroke="currentColor" stroke-width="2"/><path d="M6 4h12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M10 11v5l4-2.5z" fill="currentColor"/></svg>',
    search: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M16.5 16.5L21 21" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>',
    user: '<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4" fill="none" stroke="currentColor" stroke-width="2"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    chev: '<svg viewBox="0 0 24 24"><path d="M6 9l6 6 6-6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    prev: '<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    next: '<svg viewBox="0 0 24 24"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    star: '<svg viewBox="0 0 24 24"><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z" fill="currentColor"/></svg>',
    starO: '<svg viewBox="0 0 24 24"><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M7 4.5v15l13-7.5z" fill="currentColor"/></svg>'
  };
  const icon = (name, cls) => h('span', { class: 'ic ' + (cls || ''), html: ICON[name] });

  /* Executa tarefas assíncronas com limite (para EPG) */
  function limiter(max) {
    let active = 0; const q = [];
    const next = () => {
      if (active >= max || !q.length) return;
      active++;
      const fn = q.shift();
      fn().finally(() => { active--; next(); });
    };
    return (fn) => { q.push(fn); next(); };
  }
  const epgQueue = limiter(3);

  /* ================= Código de acesso ================= */
  const urlKey = new URLSearchParams(location.search).get('k');
  if (urlKey) Store.set('key', urlKey);
  Api.setKey(Store.get('key', ''));

  /* ================= LOGIN ================= */
  function renderLogin(errMsg) {
    closeAllPages();
    clear(app);
    const saved = Store.get('account', null) || {};
    const fServer = h('input', { type: 'text', inputmode: 'url', placeholder: 'http://servidor.com:8080', value: saved.server || '', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
    const fUser = h('input', { type: 'text', value: saved.user || '', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
    const fPass = h('input', { type: 'password', value: saved.pass || '' });
    const fTmdb = h('input', { type: 'text', value: saved.tmdb || '', placeholder: 'Opcional', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
    const fKey = h('input', { type: 'text', value: Api.getKey(), autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
    const msg = h('div', { class: 'msg', text: errMsg || '' });
    const btn = h('button', { class: 'btn primary block', type: 'submit', text: 'Entrar' });
    const form = h('form', { class: 'login-card', novalidate: true, onsubmit: async (e) => {
      e.preventDefault();
      msg.textContent = '';
      const raw = fServer.value.trim();
      const isList = /^https?:\/\//i.test(raw) && !/username=/i.test(raw) && (/\.m3u8?(\?|$)/i.test(raw) || !fUser.value.trim());
      const p = isList ? null : Api.parseServerInput(fServer.value, fUser.value, fPass.value);
      if (!isList && (!p.server || !p.user || !p.pass)) { msg.textContent = 'Preencha servidor, usuário e senha, ou cole o link de uma lista M3U.'; return; }
      const k = fKey.value.trim();
      btn.disabled = true; btn.textContent = 'Conectando…';
      if (!(await Api.checkKey(k))) {
        btn.disabled = false; btn.textContent = 'Entrar';
        msg.textContent = 'Código de acesso inválido. Ele aparece quando o servidor é instalado.';
        return;
      }
      Store.set('key', k); Api.setKey(k);
      const cfg = isList
        ? { type: 'm3u', m3u: raw, name: 'Minha lista M3U', tmdb: fTmdb.value.trim(), mediaMode: saved.mediaMode || 'auto' }
        : { server: p.server, user: p.user, pass: p.pass, tmdb: fTmdb.value.trim(), mediaMode: saved.mediaMode || 'auto' };
      try { await connect(cfg); }
      catch (err) { msg.textContent = err.message; btn.disabled = false; btn.textContent = 'Entrar'; }
    } }, [
      field('Servidor', fServer),
      field('Usuário', fUser),
      field('Senha', fPass),
      field('Chave TMDB', fTmdb, 'Fotos do elenco e sinopses melhores'),
      Api.getKey() && !errMsg ? null : field('Código de acesso', fKey, 'Fornecido na instalação do servidor'),
      btn, msg
    ]);
    if (Api.getKey() && !errMsg) form.appendChild(fKey).style.display = 'none';
    const freeBtn = h('button', { class: 'btn free block', type: 'button', onclick: async () => {
      freeBtn.disabled = true; freeBtn.textContent = 'Carregando canais…';
      try { await connect({ type: 'm3u', m3u: '/listas/brasil-ok.m3u', name: 'Canais gratuitos do Brasil', mediaMode: saved.mediaMode || 'auto' }); }
      catch (err) { msg.textContent = err.message; freeBtn.disabled = false; freeBtn.textContent = 'Assistir canais gratuitos'; }
    } }, [icon('live'), 'Assistir canais gratuitos']);
    app.appendChild(h('div', { class: 'login' }, [
      h('div', { class: 'brand' }, [h('div', { class: 'brand-mark' }, [icon('play')]), h('div', null, [h('h1', { text: 'Meu IPTV' }), h('p', { text: 'Sua lista IPTV ou canais abertos' })])]),
      h('div', { class: 'free-card' }, [
        h('h2', { text: 'Canais gratuitos do Brasil' }),
        h('p', { text: 'Emissoras abertas, notícias, Pluto TV e mais. Sem login.' }),
        freeBtn
      ]),
      h('div', { class: 'or' }, [h('span', { text: 'ou entre com a sua lista' })]),
      form,
      h('p', { class: 'hint', text: 'No campo Servidor você também pode colar um link M3U completo.' })
    ]));
  }
  function field(label, input, note) {
    return h('label', { class: 'field' }, [h('span', { text: label }), input, note ? h('small', { text: note }) : null]);
  }

  async function connect(cfg) {
    Api.setConfig(cfg);
    account = await Api.login();
    Store.set('account', cfg);
    renderShell();
  }

  /* ================= ESTRUTURA PRINCIPAL ================= */
  let mainEl, headerEl;
  const TABS = [['live', 'Ao vivo', 'live'], ['movie', 'Filmes', 'movie'], ['series', 'Séries', 'series'], ['search', 'Buscar', 'search'], ['account', 'Conta', 'user']];
  function renderShell() {
    clear(app);
    headerEl = h('header', { class: 'top' });
    mainEl = h('main', { class: 'main' });
    const tabs = Api.isM3u() ? TABS.filter(([id]) => id !== 'movie' && id !== 'series') : TABS;
    if (Api.isM3u() && (section === 'movie' || section === 'series')) section = 'live';
    const tabbar = h('nav', { class: 'tabbar' }, tabs.map(([id, label, ic]) =>
      h('button', { class: 'tab', 'data-id': id, onclick: () => openSection(id) }, [icon(ic), h('span', { text: label })])
    ));
    app.appendChild(headerEl); app.appendChild(mainEl); app.appendChild(tabbar);
    openSection(section);
  }

  function openSection(id) {
    section = id;
    if (id !== 'account') Store.set('lastSection', id);
    app.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.getAttribute('data-id') === id));
    clear(headerEl); clear(mainEl);
    window.scrollTo(0, 0);
    browseToken++;
    if (id === 'search') return renderSearch();
    if (id === 'account') return renderAccount();
    renderBrowse(id);
  }

  /* ================= NAVEGAR POR CATEGORIA ================= */
  let browseToken = 0;
  const TITLES = { live: 'Ao vivo', movie: 'Filmes', series: 'Séries' };
  async function renderBrowse(sec) {
    const my = browseToken;
    const pill = h('button', { class: 'cat-pill', onclick: () => openCatPicker(sec, cats, current, pick) }, [h('span', { text: 'Carregando…' }), icon('chev')]);
    headerEl.appendChild(h('div', { class: 'top-row' }, [h('h1', { text: TITLES[sec] }), pill]));
    let cats = [], current = null;
    try { cats = await Api.categories(sec); }
    catch (e) { if (my === browseToken) mainEl.appendChild(empty(e.message)); return; }
    if (my !== browseToken) return;
    const fav = { category_id: '__fav', category_name: 'Favoritos' };
    const all = { category_id: '', category_name: 'Todos' };
    cats = [fav, all].concat(cats);
    const savedId = Store.get('cat.' + sec, null);
    current = cats.find((c) => String(c.category_id) === String(savedId)) ||
      (Store.favList(sec).length ? fav : (cats[2] || all));
    function pick(c) {
      current = c;
      Store.set('cat.' + sec, c.category_id);
      pill.firstChild.textContent = c.category_name;
      loadCategory(sec, c);
    }
    pick(current);
  }

  async function loadCategory(sec, c) {
    const my = ++browseToken;
    clear(mainEl);
    window.scrollTo(0, 0);
    let items;
    if (c.category_id === '__fav') items = Store.favList(sec);
    else {
      mainEl.appendChild(h('div', { class: 'empty' }, [h('div', { class: 'spinner' })]));
      try { items = await Api.streams(sec, c.category_id); }
      catch (e) { if (my === browseToken) { clear(mainEl); mainEl.appendChild(empty(e.message)); } return; }
      if (my !== browseToken) return;
      clear(mainEl);
    }
    if (!items.length) {
      mainEl.appendChild(empty(c.category_id === '__fav' ? 'Nenhum favorito ainda. Abra um item e toque na estrela.' : 'Nada nesta categoria.'));
      return;
    }
    mainEl.appendChild(h('div', { class: 'count', text: items.length + (items.length === 1 ? ' item' : ' itens') }));
    const list = h('div', { class: sec === 'live' ? 'chan-list' : 'poster-grid' });
    mainEl.appendChild(list);
    renderChunked(list, items, (it, i) => sec === 'live' ? chanRow(it, i, items) : posterCard(it, sec), my);
  }

  function renderChunked(container, items, make, token) {
    let shown = 0;
    const sentinel = h('div', { class: 'sentinel' });
    function more() {
      const end = Math.min(items.length, shown + CHUNK);
      const frag = document.createDocumentFragment();
      for (let i = shown; i < end; i++) frag.appendChild(make(items[i], i));
      container.appendChild(frag);
      shown = end;
      if (shown >= items.length) { io.disconnect(); sentinel.remove(); }
    }
    const io = new IntersectionObserver((ents) => {
      if (token !== undefined && token !== browseToken) { io.disconnect(); return; }
      if (ents.some((e) => e.isIntersecting)) more();
    }, { rootMargin: '1200px' });
    container.after(sentinel);
    more();
    if (shown < items.length) io.observe(sentinel);
  }

  function empty(text) { return h('div', { class: 'empty', text }); }

  function posterCard(it, sec) {
    const r = rating(it.rating || (it.rating_5based ? it.rating_5based * 2 : ''));
    const fav = Store.isFav(sec, Store.itemId(sec, it));
    return h('button', { class: 'card', onclick: () => openDetails(sec, it) }, [
      h('div', { class: 'card-img-wrap' }, [
        img(sec === 'movie' ? it.stream_icon : it.cover, 'card-img', it.name),
        r ? h('span', { class: 'badge', text: '★ ' + r }) : null,
        fav ? h('span', { class: 'fav-dot' }, [icon('star')]) : null
      ]),
      h('div', { class: 'card-title', text: Api.cleanTitle(it.name) || it.name })
    ]);
  }

  const epgObserver = new IntersectionObserver((ents) => {
    ents.forEach((e) => {
      if (!e.isIntersecting) return;
      epgObserver.unobserve(e.target);
      const row = e.target, it = row._item, box = row.querySelector('.chan-epg');
      epgQueue(() => Api.shortEpg(it.stream_id).then((list) => {
        if (!list.length) return;
        const n = list[0];
        const pct = n.start && n.end ? Math.max(0, Math.min(100, (Date.now() - n.start) / (n.end - n.start) * 100)) : 0;
        clear(box);
        box.appendChild(h('span', { text: (n.start ? hhmm(n.start) + '  ' : '') + n.title }));
        if (pct) box.appendChild(h('i', { class: 'epg-bar' }, [h('i', { style: 'width:' + pct + '%' })]));
      }).catch(() => {}));
    });
  }, { rootMargin: '200px' });

  function chanRow(it, i, list) {
    const fav = Store.isFav('live', it.stream_id);
    const row = h('button', { class: 'chan', onclick: () => openPlayer({ kind: 'live', list, index: i }) }, [
      h('div', { class: 'chan-logo' }, [img(it.stream_icon, 'chan-img', it.name)]),
      h('div', { class: 'chan-txt' }, [
        h('div', { class: 'chan-name' }, [it.num ? h('b', { text: it.num + ' ' }) : null, it.name || '']),
        h('div', { class: 'chan-epg', text: it.group && Api.isM3u() ? it.group : '' })
      ]),
      fav ? h('span', { class: 'fav-dot inline' }, [icon('star')]) : null
    ]);
    row._item = it;
    epgObserver.observe(row);
    return row;
  }

  /* ---------- Seletor de categorias ---------- */
  function openCatPicker(sec, cats, current, pick) {
    if (!cats.length) return;
    const list = h('div', { class: 'sheet-list' });
    const search = h('input', { type: 'search', placeholder: 'Filtrar categorias', autocapitalize: 'off', autocorrect: 'off' });
    function draw() {
      clear(list);
      const q = norm(search.value);
      cats.filter((c) => !q || norm(c.category_name).includes(q)).forEach((c) => {
        list.appendChild(h('button', {
          class: 'sheet-item' + (c === current ? ' active' : ''),
          onclick: () => { close(); pick(c); }
        }, [c.category_id === '__fav' ? icon('star', 'gold') : null, c.category_name]));
      });
    }
    search.addEventListener('input', draw);
    const sheet = h('div', { class: 'sheet' }, [h('div', { class: 'sheet-grab' }), h('h2', { text: 'Categorias' }), search, list]);
    const back = h('div', { class: 'sheet-back', onclick: (e) => { if (e.target === back) close(); } }, [sheet]);
    function close() { back.classList.remove('on'); setTimeout(() => back.remove(), 250); document.body.classList.remove('lock'); }
    document.body.appendChild(back);
    document.body.classList.add('lock');
    draw();
    requestAnimationFrame(() => back.classList.add('on'));
    const act = list.querySelector('.active');
    if (act) act.scrollIntoView({ block: 'center' });
  }

  /* ================= PÁGINAS SOBREPOSTAS ================= */
  const pages = [];
  function pushPage(el) {
    pages.push(el);
    document.body.appendChild(el);
    document.body.classList.add('lock');
    requestAnimationFrame(() => el.classList.add('on'));
  }
  function popPage() {
    const el = pages.pop();
    if (!el) return;
    if (el._onClose) el._onClose();
    el.classList.remove('on');
    setTimeout(() => el.remove(), 260);
    if (!pages.length) document.body.classList.remove('lock');
    const top = pages[pages.length - 1];
    if (top && top._onResume) top._onResume();
  }
  function closeAllPages() { while (pages.length) popPage(); }

  /* ================= DETALHES ================= */
  function openDetails(type, it) {
    const isMovie = type === 'movie';
    const st = { info: {}, movieData: {}, episodes: {}, seasons: [], season: null };
    const backdrop = h('div', { class: 'det-backdrop' });
    const poster = h('div', { class: 'det-poster' }, [img(isMovie ? it.stream_icon : it.cover, 'det-poster-img', it.name)]);
    const title = h('h1', { text: Api.cleanTitle(it.name) || it.name });
    const meta = h('div', { class: 'det-meta' });
    const actions = h('div', { class: 'det-actions' });
    const plot = h('p', { class: 'det-plot' });
    const credits = h('div', { class: 'det-credits' });
    const seasonsBox = h('div', { class: 'chips' });
    const episodesBox = h('div', { class: 'episodes' });
    const castTitle = h('h2', { class: 'sec-title hidden', text: 'Elenco' });
    const castBox = h('div', { class: 'cast' });
    const page = h('div', { class: 'page' }, [
      h('div', { class: 'page-scroll' }, [
        h('div', { class: 'det-hero' }, [backdrop, h('div', { class: 'det-hero-shade' })]),
        h('div', { class: 'det-body' }, [
          h('div', { class: 'det-head' }, [poster, h('div', { class: 'det-head-txt' }, [title, meta])]),
          actions, plot, credits,
          isMovie ? null : h('div', { class: 'det-series' }, [h('h2', { class: 'sec-title', text: 'Episódios' }), seasonsBox, episodesBox]),
          castTitle, castBox
        ])
      ]),
      h('button', { class: 'round-btn back-btn', onclick: popPage, 'aria-label': 'Voltar' }, [icon('back')])
    ]);
    page._onResume = () => { drawActions(); if (!isMovie && st.season) showSeason(st.season); };
    pushPage(page);
    drawActions();

    (isMovie ? Api.vodInfo(it.stream_id) : Api.seriesInfo(it.series_id)).then((d) => {
      st.info = (d && d.info) || {};
      if (isMovie) st.movieData = d.movie_data || {};
      else {
        st.episodes = d.episodes || {};
        if (Array.isArray(st.episodes)) { const o = {}; st.episodes.forEach((list, i) => { if (list && list.length) o[list[0].season || i + 1] = list; }); st.episodes = o; }
        st.seasons = Object.keys(st.episodes).sort((a, b) => a - b);
      }
      drawInfo();
      if (!isMovie) drawSeasons();
      drawActions();
      return loadTmdb();
    }).catch((e) => toast(e.message || 'Não foi possível carregar os detalhes'));

    function first(v) { return Array.isArray(v) ? v[0] : v; }
    function setBackdrop(url) { if (url) { backdrop.style.backgroundImage = 'url("' + url + '")'; backdrop.classList.add('on'); } }

    function drawInfo() {
      const i = st.info;
      if (i.name) title.textContent = Api.cleanTitle(i.name) || i.name;
      const pUrl = isMovie ? (i.movie_image || i.cover_big || it.stream_icon) : (i.cover || it.cover);
      if (pUrl) { clear(poster); poster.appendChild(img(pUrl, 'det-poster-img', it.name)); }
      const bd = first(i.backdrop_path);
      setBackdrop(bd ? Api.media(bd) : (pUrl ? Api.media(pUrl) : ''));
      clear(meta);
      const year = (i.releasedate || i.releaseDate || i.release_date || '').substr(0, 4) || Api.yearOf(it.name);
      const r = rating(i.rating || it.rating);
      if (r) meta.appendChild(h('span', { class: 'rate', text: '★ ' + r }));
      if (year) meta.appendChild(h('span', { text: year }));
      const dur = isMovie ? (minutes(i.duration_secs) || i.duration) : '';
      if (dur) meta.appendChild(h('span', { text: dur }));
      if (!isMovie && st.seasons.length) meta.appendChild(h('span', { text: st.seasons.length + (st.seasons.length > 1 ? ' temporadas' : ' temporada') }));
      if (i.genre) meta.appendChild(h('span', { class: 'genre', text: i.genre }));
      plot.textContent = i.plot || i.description || '';
      clear(credits);
      if (i.director) credits.appendChild(h('div', null, [h('b', { text: 'Direção ' }), i.director]));
      const cast = i.cast || i.actors;
      if (cast) credits.appendChild(h('div', { class: 'cast-text' }, [h('b', { text: 'Elenco ' }), cast]));
    }

    async function loadTmdb() {
      if (!Api.tmdbOn()) return;
      const i = st.info;
      const year = (i.releasedate || i.releaseDate || '').substr(0, 4) || Api.yearOf(it.name);
      let t;
      try { t = await Api.tmdbDetails(isMovie ? 'movie' : 'tv', i.tmdb_id || i.tmdb, i.name || it.name, year); } catch (e) { return; }
      if (!t || !page.isConnected) return;
      if (t.backdrop_path) setBackdrop(Api.tmdbImg(t.backdrop_path, 'w1280'));
      if (!plot.textContent && t.overview) plot.textContent = t.overview;
      if (t.tagline) plot.insertBefore(h('em', { class: 'tagline', text: t.tagline }), plot.firstChild);
      if (!i.genre && t.genres && t.genres.length) meta.appendChild(h('span', { class: 'genre', text: t.genres.map((g) => g.name).join(', ') }));
      const cast = (t.credits && t.credits.cast || []).slice(0, 18);
      if (!cast.length) return;
      clear(castBox);
      cast.forEach((p) => castBox.appendChild(h('div', { class: 'person' }, [
        img(Api.tmdbImg(p.profile_path, 'w185'), 'person-img', p.name),
        h('div', { class: 'person-name', text: p.name }),
        h('div', { class: 'person-role', text: p.character || '' })
      ])));
      castTitle.classList.remove('hidden');
      const ct = credits.querySelector('.cast-text');
      if (ct) ct.remove();
    }

    function drawActions() {
      clear(actions);
      if (isMovie) {
        const r = Store.resumeGet('mv:' + it.stream_id);
        if (r) {
          actions.appendChild(h('button', { class: 'btn primary', onclick: () => playMovie(r.pos) }, [icon('play'), 'Continuar ' + clockTime(r.pos)]));
          actions.appendChild(h('button', { class: 'btn', onclick: () => playMovie(0), text: 'Do início' }));
        } else actions.appendChild(h('button', { class: 'btn primary', onclick: () => playMovie(0) }, [icon('play'), 'Assistir']));
      } else {
        const last = Store.get('lastep.' + it.series_id, null);
        const ep = last ? findEpisode(last) : null;
        if (ep) {
          const rr = Store.resumeGet('ep:' + ep.id);
          actions.appendChild(h('button', { class: 'btn primary', onclick: () => playEpisode(ep, rr ? rr.pos : 0) }, [icon('play'), 'Continuar T' + ep._season + 'E' + (ep.episode_num || '')]));
        } else if (st.seasons.length && st.episodes[st.seasons[0]][0]) {
          const e1 = st.episodes[st.seasons[0]][0]; e1._season = st.seasons[0];
          actions.appendChild(h('button', { class: 'btn primary', onclick: () => playEpisode(e1, 0) }, [icon('play'), 'Assistir T' + e1._season + 'E' + (e1.episode_num || 1)]));
        }
      }
      const on = Store.isFav(type, Store.itemId(type, it));
      actions.appendChild(h('button', { class: 'btn icon-only' + (on ? ' gold' : ''), 'aria-label': 'Favorito', onclick: () => {
        const now = Store.toggleFav(type, it);
        toast(now ? 'Adicionado aos favoritos' : 'Removido dos favoritos');
        drawActions();
      } }, [icon(on ? 'star' : 'starO')]));
    }

    function playMovie(at) {
      openPlayer({
        kind: 'movie', title: Api.cleanTitle(st.info.name || it.name), sub: st.info.genre || '',
        url: Api.movieUrl(it.stream_id, st.movieData.container_extension || it.container_extension),
        ext: st.movieData.container_extension || it.container_extension,
        resumeKey: 'mv:' + it.stream_id, startAt: at
      });
    }

    function drawSeasons() {
      clear(seasonsBox);
      st.seasons.forEach((s) => seasonsBox.appendChild(h('button', { class: 'chip', 'data-s': s, onclick: () => showSeason(s), text: 'Temporada ' + s })));
      if (st.seasons.length) {
        const last = Store.get('lastep.' + it.series_id, null), ep = last ? findEpisode(last) : null;
        showSeason(ep ? ep._season : st.seasons[0]);
      }
    }
    function showSeason(s) {
      st.season = s;
      seasonsBox.querySelectorAll('.chip').forEach((c) => c.classList.toggle('active', c.getAttribute('data-s') === String(s)));
      clear(episodesBox);
      (st.episodes[s] || []).forEach((ep) => {
        ep._season = s;
        const info = ep.info || {};
        const r = Store.resumeGet('ep:' + ep.id);
        episodesBox.appendChild(h('button', { class: 'ep', onclick: () => playEpisode(ep, r ? r.pos : 0) }, [
          h('div', { class: 'ep-thumb-wrap' }, [
            img(info.movie_image || info.cover_big || st.info.cover, 'ep-thumb', ep.title),
            r ? h('div', { class: 'ep-progress' }, [h('i', { style: 'width:' + Math.round(r.pos / r.dur * 100) + '%' })]) : null
          ]),
          h('div', { class: 'ep-txt' }, [
            h('div', { class: 'ep-title', text: (ep.episode_num ? ep.episode_num + '. ' : '') + epTitle(ep) }),
            h('div', { class: 'ep-num', text: info.duration_secs ? minutes(info.duration_secs) : (info.duration || '') }),
            info.plot ? h('div', { class: 'ep-plot', text: info.plot }) : null
          ])
        ]));
      });
    }
    function epTitle(ep) {
      const t = String(ep.title || '');
      const m = t.match(/S\d+\s*E\d+\s*[-–:]?\s*(.*)$/i);
      return (m && m[1]) || t || ('Episódio ' + ep.episode_num);
    }
    function findEpisode(id) {
      for (const s in st.episodes) {
        const e = (st.episodes[s] || []).find((x) => String(x.id) === String(id));
        if (e) { e._season = s; return e; }
      }
      return null;
    }
    function nextEpisode(ep) {
      const list = st.episodes[ep._season] || [], i = list.indexOf(ep);
      if (i > -1 && i < list.length - 1) { list[i + 1]._season = ep._season; return list[i + 1]; }
      const si = st.seasons.indexOf(String(ep._season));
      if (si > -1 && si < st.seasons.length - 1) {
        const ns = st.seasons[si + 1], n = st.episodes[ns][0];
        if (n) { n._season = ns; return n; }
      }
      return null;
    }
    function playEpisode(ep, at) {
      Store.set('lastep.' + it.series_id, ep.id);
      openPlayer({
        kind: 'episode', title: Api.cleanTitle(st.info.name || it.name),
        sub: 'T' + ep._season + ' · E' + (ep.episode_num || '') + ' — ' + epTitle(ep),
        url: Api.episodeUrl(ep), ext: ep.container_extension, resumeKey: 'ep:' + ep.id, startAt: at,
        next: () => {
          const n = nextEpisode(ep);
          if (!n) return null;
          Store.set('lastep.' + it.series_id, n.id);
          ep = n;
          return { title: Api.cleanTitle(st.info.name || it.name), sub: 'T' + n._season + ' · E' + (n.episode_num || '') + ' — ' + epTitle(n), url: Api.episodeUrl(n), ext: n.container_extension, resumeKey: 'ep:' + n.id };
        }
      });
    }
  }

  /* ================= PLAYER ================= */
  function openPlayer(o) {
    const video = h('video', { controls: true, playsinline: true, 'webkit-playsinline': true, 'x-webkit-airplay': 'allow', preload: 'auto' });
    const titleEl = h('div', { class: 'pl-title' });
    const subEl = h('div', { class: 'pl-sub' });
    const msg = h('div', { class: 'pl-msg hidden' });
    const airBtn = h('button', { class: 'round-btn air hidden', 'aria-label': 'AirPlay', onclick: () => { try { video.webkitShowPlaybackTargetPicker(); } catch (e) { toast('Use o botão de AirPlay no próprio vídeo'); } } }, [icon('airplay')]);
    const extra = h('div', { class: 'pl-extra' });
    const page = h('div', { class: 'page player' }, [
      h('div', { class: 'pl-bar' }, [
        h('button', { class: 'round-btn', onclick: popPage, 'aria-label': 'Fechar' }, [icon('back')]),
        h('div', { class: 'pl-heading' }, [titleEl, subEl]),
        airBtn
      ]),
      h('div', { class: 'pl-video' }, [video, msg]),
      extra
    ]);
    let saveTimer = null, cur = o;

    if (window.WebKitPlaybackTargetAvailabilityEvent) {
      video.addEventListener('webkitplaybacktargetavailabilitychanged', (e) => airBtn.classList.toggle('hidden', e.availability !== 'available'));
    }
    video.addEventListener('webkitcurrentplaybacktargetiswirelesschanged', () => {
      if (video.webkitCurrentPlaybackTargetIsWireless) toast('Transmitindo para a TV');
    });
    video.addEventListener('error', () => {
      const ext = String(cur.ext || '').toLowerCase();
      msg.classList.remove('hidden');
      msg.textContent = cur.kind === 'live'
        ? 'Este canal não está transmitindo agora.'
        : (ext && ext !== 'mp4' && ext !== 'm4v' && ext !== 'mov'
          ? 'Este vídeo está em ' + ext.toUpperCase() + ', formato que o iPhone/iPad não reproduz.'
          : 'Não foi possível reproduzir este vídeo.');
    });
    video.addEventListener('playing', () => msg.classList.add('hidden'));
    video.addEventListener('ended', () => {
      if (cur.resumeKey) Store.resumeSet(cur.resumeKey, 0, 0);
      const n = o.next && o.next();
      if (n) { toast('Próximo episódio'); cur = Object.assign({}, o, n, { startAt: 0 }); start(); }
    });

    function save() {
      if (cur.resumeKey && video.duration && isFinite(video.duration)) Store.resumeSet(cur.resumeKey, video.currentTime, video.duration);
    }
    function start() {
      msg.classList.add('hidden');
      if (cur.kind === 'live') {
        const ch = o.list[o.index];
        titleEl.textContent = (ch.num ? ch.num + '  ' : '') + ch.name;
        subEl.textContent = '';
        video.src = Api.liveUrl(ch);
        Api.shortEpg(ch.stream_id).then((l) => {
          if (o.list[o.index] !== ch || !l.length) return;
          subEl.textContent = 'Agora: ' + l[0].title + (l[0].start ? ' · ' + hhmm(l[0].start) + '–' + hhmm(l[0].end) : '');
        }).catch(() => {});
        markActive();
      } else {
        titleEl.textContent = cur.title || '';
        subEl.textContent = cur.sub || '';
        video.src = cur.url;
        if (cur.startAt) {
          const once = () => { video.removeEventListener('loadedmetadata', once); try { video.currentTime = cur.startAt; } catch (e) {} };
          video.addEventListener('loadedmetadata', once);
        }
      }
      const p = video.play();
      if (p && p.catch) p.catch(() => {});
    }

    /* Lista de canais abaixo do vídeo, para trocar com um toque */
    let rows = [];
    function markActive() {
      rows.forEach((r, i) => r.classList.toggle('active', i === o.index));
      const a = rows[o.index];
      if (a) a.scrollIntoView({ block: 'nearest' });
    }
    if (o.kind === 'live') {
      const nav = h('div', { class: 'zap' }, [
        h('button', { class: 'btn', onclick: () => zap(-1) }, [icon('prev'), 'Anterior']),
        h('button', { class: 'btn icon-only', 'aria-label': 'Favorito', onclick: favLive }, [icon('starO')]),
        h('button', { class: 'btn', onclick: () => zap(1) }, ['Próximo', icon('next')])
      ]);
      const list = h('div', { class: 'zap-list' });
      rows = o.list.slice(0, 400).map((ch, i) => {
        const r = h('button', { class: 'zap-item', onclick: () => { o.index = i; start(); } }, [
          h('div', { class: 'chan-logo sm' }, [img(ch.stream_icon, 'chan-img', ch.name)]),
          h('span', { text: (ch.num ? ch.num + '  ' : '') + ch.name })
        ]);
        list.appendChild(r);
        return r;
      });
      extra.appendChild(nav); extra.appendChild(list);
      updateFavBtn();
      function zap(d) { o.index = (o.index + d + o.list.length) % o.list.length; start(); updateFavBtn(); }
      function favLive() {
        const ch = o.list[o.index];
        toast(Store.toggleFav('live', ch) ? 'Canal nos favoritos' : 'Removido dos favoritos');
        updateFavBtn();
      }
      function updateFavBtn() {
        const b = nav.children[1], on = Store.isFav('live', o.list[o.index].stream_id);
        b.classList.toggle('gold', on);
        clear(b); b.appendChild(icon(on ? 'star' : 'starO'));
      }
    } else {
      extra.appendChild(h('p', { class: 'pl-tip', text: 'Para ver na TV, toque no ícone de AirPlay e escolha a TV. O iPhone pode ser bloqueado durante a transmissão.' }));
      saveTimer = setInterval(save, 10000);
    }

    page._onClose = () => {
      save();
      clearInterval(saveTimer);
      try { video.pause(); } catch (e) {}
      video.removeAttribute('src');
      try { video.load(); } catch (e) {}
    };
    pushPage(page);
    start();
  }

  /* ================= BUSCA ================= */
  const catalog = { live: null, movie: null, series: null };
  function renderSearch() {
    const input = h('input', { type: 'search', class: 'search-input', placeholder: 'Canais, filmes e séries', autocapitalize: 'off', autocorrect: 'off', enterkeyhint: 'search', value: Store.get('lastSearch', '') });
    headerEl.appendChild(h('div', { class: 'top-row' }, [h('h1', { text: 'Buscar' })]));
    headerEl.appendChild(h('div', { class: 'search-wrap' }, [icon('search'), input]));
    let timer;
    input.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(run, 450); });
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { input.blur(); run(); } });
    const my = browseToken;
    run();
    async function run() {
      const q = norm(input.value).trim();
      Store.set('lastSearch', input.value);
      clear(mainEl);
      if (q.length < 2) { mainEl.appendChild(empty('Digite pelo menos 2 letras.')); return; }
      if (!catalog.live || !catalog.movie || !catalog.series) {
        mainEl.appendChild(h('div', { class: 'empty' }, [h('div', { class: 'spinner' }), h('div', { class: 'mt', text: 'Preparando a busca (só na primeira vez)…' })]));
        try {
          await Promise.all(['live', 'movie', 'series'].map(async (t) => {
            if (!catalog[t]) catalog[t] = (await Api.streams(t, null)).map((x) => { x._q = norm(x.name); return x; });
          }));
        } catch (e) { if (my === browseToken) { clear(mainEl); mainEl.appendChild(empty(e.message)); } return; }
        if (my !== browseToken || norm(input.value).trim() !== q) return;
        clear(mainEl);
      }
      const words = q.split(/\s+/);
      const match = (x) => words.every((w) => x._q.includes(w));
      let total = 0;
      [['live', 'Canais'], ['movie', 'Filmes'], ['series', 'Séries']].forEach(([t, label]) => {
        const found = catalog[t].filter(match);
        if (!found.length) return;
        total += found.length;
        const shown = found.slice(0, t === 'live' ? 30 : 60);
        const box = h('div', { class: t === 'live' ? 'chan-list' : 'poster-grid' },
          shown.map((it, i) => t === 'live' ? chanRow(it, i, shown) : posterCard(it, t)));
        mainEl.appendChild(h('h2', { class: 'sec-title', text: label + ' · ' + found.length }));
        mainEl.appendChild(box);
      });
      if (!total) mainEl.appendChild(empty('Nada encontrado.'));
    }
  }

  /* ================= CONTA ================= */
  function renderAccount() {
    headerEl.appendChild(h('div', { class: 'top-row' }, [h('h1', { text: 'Conta' })]));
    const cfg = Api.getConfig(), u = (account && account.user_info) || {}, s = (account && account.server_info) || {};
    if (Api.isM3u()) {
      const isFree = cfg.m3u === '/listas/brasil-ok.m3u';
      const info = h('div', { class: 'kv' }, [
        h('div', null, [h('span', { text: 'Lista' }), h('b', { text: cfg.name || 'Lista M3U' })]),
        h('div', null, [h('span', { text: 'Canais' }), h('b', { text: String(account && account.total || '—') })])
      ]);
      mainEl.appendChild(h('div', { class: 'panel' }, [info]));
      if (isFree) {
        const st = h('p', { class: 'note', text: 'Os canais vêm do projeto público iptv-org e de serviços gratuitos (Pluto TV, Samsung TV Plus). O servidor testa todos a cada 6 horas e mostra só os que estão funcionando.' });
        mainEl.appendChild(h('div', { class: 'panel' }, [h('h3', { text: 'Sobre os canais' }), st]));
        fetch('/listas/status.json', { cache: 'no-store' }).then((r) => r.ok ? r.json() : null).then((j) => {
          if (j) st.appendChild(document.createTextNode(' Última verificação: ' + new Date(j.checkedAt).toLocaleString('pt-BR') + ' (' + j.working + ' de ' + j.total + ' funcionando).'));
        }).catch(() => {});
      }
      mainEl.appendChild(h('button', { class: 'btn danger block', onclick: () => {
        Store.del('account'); account = null;
        catalog.live = catalog.movie = catalog.series = null;
        renderLogin();
      }, text: 'Trocar de lista' }));
      return;
    }
    const rows = [
      ['Servidor', cfg.server], ['Usuário', cfg.user],
      ['Status', u.status === 'Active' ? 'Ativa' : (u.status || '—')],
      ['Vencimento', dateBR(u.exp_date)],
      ['Telas simultâneas', (u.active_cons || 0) + ' de ' + (u.max_connections || '—')],
      ['Fuso do servidor', s.timezone || '—']
    ];
    const tmdb = h('input', { type: 'text', value: cfg.tmdb || '', placeholder: 'Cole sua chave da API do TMDB', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false' });
    tmdb.addEventListener('change', () => {
      cfg.tmdb = tmdb.value.trim(); Api.setConfig(cfg); Store.set('account', cfg);
      toast(cfg.tmdb ? 'Chave TMDB salva' : 'TMDB desativado');
    });
    const modes = [['auto', 'Automático'], ['direct', 'Direto'], ['proxy', 'Pelo servidor']];
    const seg = h('div', { class: 'seg' }, modes.map(([id, label]) => h('button', {
      class: (cfg.mediaMode || 'auto') === id ? 'active' : '', onclick: (e) => {
        cfg.mediaMode = id; Api.setConfig(cfg); Store.set('account', cfg);
        seg.querySelectorAll('button').forEach((b) => b.classList.toggle('active', b === e.currentTarget));
        toast('Modo de vídeo: ' + label);
      }, text: label
    })));
    mainEl.appendChild(h('div', { class: 'panel' }, [
      h('div', { class: 'kv' }, rows.map(([k, v]) => h('div', null, [h('span', { text: k }), h('b', { text: v })])))
    ]));
    mainEl.appendChild(h('div', { class: 'panel' }, [
      h('h3', { text: 'Informações extras (TMDB)' }),
      h('p', { class: 'note', text: 'Com uma chave gratuita do themoviedb.org o app mostra fotos do elenco, fundos em alta e sinopses em português.' }),
      tmdb
    ]));
    mainEl.appendChild(h('div', { class: 'panel' }, [
      h('h3', { text: 'Vídeo' }),
      h('p', { class: 'note', text: 'Use "Pelo servidor" só se os vídeos não abrirem no modo automático. Nesse modo o vídeo passa pelo seu servidor e consome a banda dele.' }),
      seg
    ]));
    mainEl.appendChild(h('button', { class: 'btn danger block', onclick: () => {
      if (!confirm('Sair da conta neste aparelho?')) return;
      Store.del('account'); account = null;
      catalog.live = catalog.movie = catalog.series = null;
      renderLogin();
    }, text: 'Sair da conta' }));
  }

  /* ================= INÍCIO ================= */
  const saved = Store.get('account', null);
  const freeSaved = saved && saved.type === 'm3u' && String(saved.m3u || '')[0] === '/';
  if (saved && (freeSaved || ((saved.server && saved.user || saved.type === 'm3u') && Api.getKey()))) {
    clear(app);
    app.appendChild(h('div', { class: 'splash' }, [h('div', { class: 'brand-mark big' }, [icon('play')]), h('div', { class: 'spinner' })]));
    connect(saved).catch((e) => renderLogin(e.message));
  } else renderLogin();
})();
