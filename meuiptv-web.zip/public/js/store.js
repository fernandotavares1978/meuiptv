/* Armazenamento local: conta, favoritos, posição de "continuar assistindo" */
var Store = (function () {
  var PREFIX = 'meuiptv.';

  function get(key, def) {
    try {
      var v = localStorage.getItem(PREFIX + key);
      return v === null ? def : JSON.parse(v);
    } catch (e) { return def; }
  }
  function set(key, val) {
    try { localStorage.setItem(PREFIX + key, JSON.stringify(val)); } catch (e) {}
  }
  function del(key) {
    try { localStorage.removeItem(PREFIX + key); } catch (e) {}
  }

  /* ---- Favoritos: { live: {id: item}, movie: {...}, series: {...} } ---- */
  function favs() { return get('favs', { live: {}, movie: {}, series: {} }); }
  function isFav(type, id) { return !!favs()[type][String(id)]; }
  function toggleFav(type, item) {
    var f = favs(), id = String(itemId(type, item));
    if (f[type][id]) delete f[type][id];
    else f[type][id] = item;
    set('favs', f);
    return !!f[type][id];
  }
  function favList(type) {
    var f = favs()[type], out = [];
    for (var k in f) if (f.hasOwnProperty(k)) out.push(f[k]);
    return out;
  }
  function itemId(type, item) {
    return type === 'series' ? item.series_id : item.stream_id;
  }

  /* ---- Continuar assistindo: key -> {pos, dur, t} ---- */
  function resumeGet(key) {
    var r = get('resume', {});
    return r[key] || null;
  }
  function resumeSet(key, pos, dur) {
    var r = get('resume', {});
    if (!dur || pos < 30 || pos > dur - 60) { delete r[key]; }
    else r[key] = { pos: Math.floor(pos), dur: Math.floor(dur), t: Date.now() };
    // mantém no máximo 300 entradas
    var keys = Object.keys(r);
    if (keys.length > 300) {
      keys.sort(function (a, b) { return r[a].t - r[b].t; });
      for (var i = 0; i < keys.length - 300; i++) delete r[keys[i]];
    }
    set('resume', r);
  }

  return {
    get: get, set: set, del: del,
    isFav: isFav, toggleFav: toggleFav, favList: favList, itemId: itemId,
    resumeGet: resumeGet, resumeSet: resumeSet
  };
})();
